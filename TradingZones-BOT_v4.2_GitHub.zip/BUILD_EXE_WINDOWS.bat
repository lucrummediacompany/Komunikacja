@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo TradingZones-BOT v4.2 - budowanie EXE Windows
echo Nie sa potrzebne klucze OKX, seed ani uprawnienia administratora.
py -3 -c "import sys; assert sys.version_info >= (3,11), 'Wymagany Python 3.11 lub nowszy'"
if errorlevel 1 goto fail
if not exist ".build-venv\Scripts\python.exe" (
  py -3 -m venv .build-venv
  if errorlevel 1 goto fail
)
".build-venv\Scripts\python.exe" -m pip install -r requirements-build.txt
if errorlevel 1 goto fail
".build-venv\Scripts\python.exe" -m unittest discover -s tests -p "test_*.py" -q
if errorlevel 1 goto fail
".build-venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --console --noupx --name TradingZones-BOT-v4.2 --add-data "static:static" --collect-all truststore launcher.py
if errorlevel 1 goto fail
"dist\TradingZones-BOT-v4.2.exe" --self-test
if errorlevel 1 goto fail
".build-venv\Scripts\python.exe" -c "import hashlib,pathlib; p=pathlib.Path('dist/TradingZones-BOT-v4.2.exe'); s=hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'; p.with_suffix('.exe.sha256').write_text(s,encoding='ascii'); print(s)"
if errorlevel 1 goto fail
".build-venv\Scripts\python.exe" -m pip freeze > "dist\BUILD_DEPENDENCIES.txt"
".build-venv\Scripts\python.exe" collect_build_licenses.py
if errorlevel 1 goto fail
echo.
echo GOTOWE: dist\TradingZones-BOT-v4.2.exe
echo Sprawdz uruchomienie panelu i zalacznik WINDOWS_EXE.md przed wydaniem.
pause
exit /b 0
:fail
echo.
echo BLAD. EXE nie zostalo zatwierdzone do wydania. Zachowaj komunikat powyzej.
pause
exit /b 1
