# TradingZones-BOT v4.2

Prezentacja możliwości analitycznych Trading Zones w lokalnej aplikacji Windows: analiza rynku, zakup raportów przez x402 na Base i opcjonalne przygotowanie potwierdzonego przez użytkownika zlecenia OKX. Panel działa wyłącznie na `127.0.0.1`.

Wersja 4.2 dodaje stopkę z informacjami o ryzyku, dane firmy oraz lokalną stronę warunków i prywatności. Własne nowe elementy v4.2 są source-available na warunkach LICENSE; nie należy określać całej v4.2 jako open source. Wcześniejsze uprawnienia MIT i licencje zależności pozostają bez zmian. Udostępnienie tej paczki w repozytorium Komunikacja nie zmienia licencji samego SDK.

## Użytkownicy Windows

Gotowy plik `TradingZones-BOT-v4.2.exe` jest udostępniany osobno po zbudowaniu. Do uruchomienia EXE nie trzeba instalować Pythona ani Node.js. Do płatności Base wymagane są Google Chrome i rozszerzenie portfela EVM; do OKX własne dane API.

Uruchom program jako zwykły użytkownik. Konsola pozostaje otwarta podczas pracy; jej zamknięcie zatrzymuje lokalny serwer. Nie zamykaj starej sesji, jeżeli nadal obsługuje aktywną pozycję.

## Uruchomienie ze źródeł

Wymagany Python 3.11+:

```text
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python app.py
```

Na Windows można też uruchomić `run_windows.bat`. Gotowy frontend `static/app.bundle.js` jest dołączony. Wszystkie pliki źródłowe archiwum znajdują się bezpośrednio w jego głównym katalogu.

## Funkcje

- Darmowy TZ-SELECT 4H: wybrany rynek, kierunek, Entry Reference, SL LQ, TP LQ i ważność.
- Osobne płatne analizy BTC, ETH, XRP, ONDO i TZ-SELECT.
- Pełny raport: kontekst setupu, dziewięć wskaźników, historia skuteczności i dane pakietu.
- Płatność x402 v2: Base Mainnet, oficjalny USDC, 0,03 USDC i przypięty odbiorca. Podpis w rozszerzeniu portfela.
- Zlecenie OKX: pojedyncze wejście MARKET z dołączonymi TP LQ LIMIT i SL LQ LIMIT, podgląd oraz jawne potwierdzenie.
- Automatyczne wykonanie w oficjalnym kliencie wymaga zweryfikowanego konta partnerskiego. Zakup analiz jest od tego niezależny.
- Opcjonalny zapis danych OKX przez Windows DPAPI.
- Ceny BTC/ETH do dwóch miejsc, XRP/ONDO do czterech; zaokrąglenie dotyczy wyłącznie prezentacji.

Bot nie prowadzi pozycji według siatki, runnera ani automatycznych korekt. Niektóre selektorowe odpowiedzi NO_TRADE z symbolem TZ-SELECT są odrzucane przez walidator; w takim przypadku zlecenie pozostaje zablokowane.

## Bezpieczeństwo i dane

Nie wpisuj seeda, frazy odzyskiwania ani klucza prywatnego portfela. Klucz OKX powinien mieć wyłącznie Read i Trade, bez Withdraw; zalecane przypięcie IP.

Dane OKX pozostają w lokalnym procesie i są używane do połączenia z OKX. Do Trading Zones przy weryfikacji partnerstwa trafia mainUid konta głównego. Zapis DPAPI jest poza katalogiem programu, w LOCALAPPDATA. DPAPI nie chroni przed przejętym kontem Windows ani złośliwym programem działającym jako ten sam użytkownik.

Kod lokalnego klienta może zostać zmodyfikowany przez właściciela kopii. Lokalne ograniczenie afiliacji nie jest granicą bezpieczeństwa serwera. Szczegóły ochrony i ograniczenia: [SECURITY.md](SECURITY.md).

## Testy

```text
python -m unittest discover -s tests -v
```

Testy używają atrap i lokalnych serwerów testowych. Nie wykonują prawdziwych transakcji ani płatności.

## Źródła interfejsu

Wymagany Node.js z npm:

```text
npm ci
npm run check
npm run test:x402
npm run build
```

Kod interfejsu znajduje się w `src/app.js`, a pliki HTML i CSS w `static/`. Odtworzenie frontendowego bundle wymaga jego źródeł i plików package.json/package-lock.json.

## Budowanie Windows EXE

Uruchom `BUILD_EXE_WINDOWS.bat` na Windows. Skrypt przygotuje osobne środowisko budowania, wykona testy, zbuduje jedno EXE i uruchomi self-test. Wynik: `dist/TradingZones-BOT-v4.2.exe`, suma SHA-256 i informacje o zależnościach.

Szczegóły, test przed wydaniem i licencje dystrybucji: [WINDOWS_EXE.md](WINDOWS_EXE.md).

## Ograniczenia handlowe

Materiał informacyjny; brak gwarancji wyniku. Entry Reference nie jest gwarantowaną ceną wykonania. Zlecenia stop-limit mogą nie zostać wykonane przy luce cenowej. Po wysłaniu zlecenia sprawdź pozycję, wielkość, dźwignię, TP i SL bezpośrednio w OKX.

## Licencje

Własny kod i nowe elementy v4.2: [Trading Zones Source Available License 1.0](LICENSE). Zależności zachowują własne licencje: [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) i `third_party_licenses/`. Wcześniej udzielone uprawnienia MIT do v4.1 i jej fragmentów nie są cofane; informacja w `legacy_licenses/`.

Licencja kodu nie obejmuje płatnych odpowiedzi API, analiz, znaków towarowych ani niezależnych grafik partnerów. Ich warunki pozostają odrębne.

## Operator i dokumenty

LUCRUM MEDIA COMPANY sp. z o.o., ul. Boryńska 8B, 44-240 Żory, Polska. NIP 6511751012, KRS 0001181306. Kontakt: lucrum.media.company@gmail.com; https://tradingzones.app/.

Informacje prawne dostępne są w aplikacji oraz w `static/legal.html`. Dokumenty i określenie materiału jako analizy nie stanowią certyfikacji zgodności regulacyjnej; przed publicznym wydaniem operator powinien zatwierdzić ich zgodność z rzeczywistym sposobem świadczenia usług.
