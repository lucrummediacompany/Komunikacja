# Bezpieczeństwo TradingZones‑BOT

## Najważniejsza zasada

Nigdy nie wpisuj w TradingZones‑BOT frazy odzyskiwania, seeda, klucza prywatnego
ani hasła do portfela. Aplikacja nie zawiera pól do wprowadzania takich danych.

## Przypięta polityka x402

- protokół: x402 v2;
- schemat: `exact`;
- sieć: Base Mainnet `eip155:8453`;
- aktywo: oficjalny USDC `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`;
- kwota: `30000` jednostek atomowych, czyli 0,03 USDC;
- odbiorca: `0x449352D4B7A7928dBE64eec73B2427B7b3C98e81`;
- domena zasobu: `https://api.tradingzones.app`.

Zmiana któregokolwiek z tych parametrów blokuje płatność. Każdy zakup wymaga
osobnego kliknięcia i podpisu w portfelu.

## Ochrona aplikacji lokalnej

- serwer nasłuchuje wyłącznie na `127.0.0.1`;
- Host musi wskazywać loopback oraz rzeczywisty port serwera, a podany Origin musi odpowiadać tej usłudze;
- płatne proxy i uruchomienie Chrome wymagają losowego tokenu sesji;
- płatność jest przekazywana wyłącznie do przypiętych endpointów;
- odpowiedź API musi przejść walidację przed pokazaniem lub użyciem.
- połączenia z API używają HTTPS i nie podążają za przekierowaniami;
- lokalne HTML i API blokują osadzanie w ramce, a serwer nie udostępnia list katalogów.

## Dane i zlecenia OKX

- klucz OKX powinien mieć wyłącznie `Read` i `Trade`, nigdy `Withdraw`;
- zalecane jest przypięcie klucza do adresu IP;
- dane działają w pamięci procesu i nie trafiają do `localStorage`;
- opcjonalny zapis na Windows używa DPAPI i jest związany z kontem Windows;
- DPAPI nie chroni przed złośliwym programem działającym jako ten sam użytkownik; token CSRF nie uwierzytelnia innych procesów lokalnych;
- zaszyfrowany plik znajduje się poza katalogiem aplikacji w `LOCALAPPDATA`;
- saldo, pozycje, oczekujące zlecenia, cena i dźwignia są odczytywane ponownie
  bezpośrednio przed wysłaniem zlecenia;
- `set-leverage` nie wystarcza: bot wymaga zgodnego odczytu `leverage-info`;
- aplikacja działa w trybie Live i zawsze pokazuje finalne ostrzeżenie;
- zamówienie wejścia zawiera jednocześnie MARKET, TP LQ LIMIT i SL LQ LIMIT.

Poziomy limit mogą nie zostać wykonane przy luce cenowej. Aplikacja nie jest
systemem gwarantującym wykonanie ani ochronę przed stratą.

## Oficjalna dystrybucja

Korzystaj wyłącznie z oficjalnych wydań Trading Zones. Przed uruchomieniem
porównaj sumę SHA‑256 paczki z wartością opublikowaną przy wydaniu. Zmodyfikowane
forki mogą zmienić linki, odbiorcę płatności albo zachowanie aplikacji.

Udostępnione źródła ujawniają mechanikę klienta, adresy publicznych API, adres odbiorcy
płatności i kod afiliacji. Nie zawiera kodu selektora AI ani kluczy serwerów.
Lokalna weryfikacja afiliacji może zostać usunięta w zmodyfikowanym kliencie;
nie jest zabezpieczeniem serwera przed autorem takiej modyfikacji.

Warunki własnego kodu v4.2 są source-available; licencje bibliotek i wcześniej
udzielone uprawnienia MIT pozostają bez zmian. Informacje o ryzyku, danych
i operatorze są dostępne w stopce oraz w static/legal.html.
