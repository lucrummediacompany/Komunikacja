# Third-party notices

Client dependencies retain their own licenses. Full available package license and NOTICE files are in third_party_licenses/. The frontend bundle retains bundled license comments. No license on client code grants rights to paid API data or partner trademarks.

The v4.2 application license does not restrict rights already granted for v4.1 MIT code or any third-party component. See legacy_licenses/v4.1-MIT.txt. Restrictions apply only within the licensor's rights to new v4.2 material; the public Komunikacja SDK retains its existing license.

| Package | Version | License | Files |
|---|---|---|---|
| abitype | 1.2.3 | MIT | abitype__LICENSE |
| esbuild | 0.25.12 | MIT | esbuild__LICENSE.md |
| eventemitter3 | 5.0.1 | MIT | eventemitter3__LICENSE |
| isows | 1.0.7 | MIT | isows__LICENSE |
| ox | 0.14.63 | MIT | ox__LICENSE |
| viem | 2.57.17 | MIT | viem__LICENSE |
| ws | 8.21.0 | MIT | ws__LICENSE |
| zod | 4.6.7 | MIT | zod__LICENSE |
| @adraffy/ens-normalize | 1.11.1 | MIT | adraffy__ens-normalize__LICENSE |
| @noble/ciphers | 1.3.0 | MIT | noble__ciphers__LICENSE |
| @noble/curves | 1.9.1 | MIT | noble__curves__LICENSE |
| @noble/hashes | 1.8.0 | MIT | noble__hashes__LICENSE |
| @scure/base | 1.2.6 | MIT | scure__base__LICENSE |
| @scure/bip32 | 1.7.0 | MIT | scure__bip32__LICENSE |
| @scure/bip39 | 1.6.0 | MIT | scure__bip39__LICENSE |
| @x402/core | 2.30.0 | Apache-2.0 | x402__core__LICENSE, x402__core__NOTICE |
| @x402/evm | 2.30.0 | Apache-2.0 | x402__evm__LICENSE, x402__evm__NOTICE |
| @x402/fetch | 2.30.0 | Apache-2.0 | x402__fetch__LICENSE, x402__fetch__NOTICE |

Python runtime dependency: truststore 0.10.4 (MIT). EXE packaging tool: PyInstaller 6.22.3 (GPL with bootloader distribution exception; see official package license). The build gathers the licenses shipped with installed Python distributions. The Python interpreter retains the PSF license.
