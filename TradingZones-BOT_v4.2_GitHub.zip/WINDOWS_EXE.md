# Budowanie EXE v4.2

1. Rozpakuj caly katalog do nowego folderu. Zainstaluj Python 3.11+ z oficjalnej strony python.org wraz z Python Launcher (`py`).
2. Kliknij `BUILD_EXE_WINDOWS.bat`. Nie uruchamiaj jako administrator i nie podawaj zadnych sekretow podczas budowania.
3. Skrypt tworzy osobne `.build-venv`, instaluje przypiete glowne zaleznosci, uruchamia testy, buduje jedno EXE i wykonuje `--self-test` (pliki interfejsu, kontekst TLS, Windows DPAPI). Node nie jest potrzebny, bo gotowy bundle jest dolaczony.
4. Wynik: `dist/TradingZones-BOT-v4.2.exe`, suma `.exe.sha256` i lista `BUILD_DEPENDENCIES.txt`.
5. Przed publikacja zamknij stara sesje, o ile nie obsluguje aktywnej pozycji. Otworz EXE jako zwykly uzytkownik. Sprawdz trzy zakladki, pobranie darmowej analizy, otwarcie Chrome, polaczenie Base i wczytanie zapisu DPAPI. Sam build NIE wykonuje zakupow ani zlecen. Test realnej platnosci lub transakcji wykonuje wlasciciel konta.
6. Uzytkownik EXE nie potrzebuje Pythona ani Node. Nadal potrzebuje Chrome i rozszerzenia portfela dla Base oraz wlasnych danych API dla OKX. Konsola pozostaje otwarta podczas pracy; jej zamkniecie zatrzymuje program. Aplikacja nie jest usluga prowadzaca pozycje.

Warunkiem wydania jest przejscie powyzszego testu na docelowym Windows. PyInstaller buduje program dla systemu, na ktorym jest uruchomiony; EXE Windows nalezy budowac na Windows.

EXE nie jest podpisane certyfikatem wydawcy. Nie wylaczaj Defendera ani SmartScreen. Podpis wydawcy mozna dodac pozniej legalnie posiadanym certyfikatem; nie jest dolaczony do paczki. Suma SHA-256 sprawdza zgodnosc pliku z opublikowana suma, a nie sama w sobie wiarygodnosc wydawcy.

Do GitHub wrzuc kod z paczki; do Releases ewentualnie przetestowane EXE, sume i pliki licencyjne `LICENSE`, `THIRD_PARTY_NOTICES.md`, `third_party_licenses/`. Nigdy `.venv`, `.build-venv`, `node_modules`, `build`, plikow `.env`, zapisow kluczy, prywatnych analiz, logow ani danych konta. `.gitignore` pomaga, ale nie usuwa plikow juz sledzonych przez Git.

PyInstaller pakuje program, nie szyfruje jego kodu i nie zmienia go w serwer. Sekrety nie moga byc zaszyte w EXE. Zapis DPAPI pozostaje w LOCALAPPDATA poza katalogiem aplikacji.
