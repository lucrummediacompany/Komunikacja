from __future__ import annotations

import base64
import json
import os
import secrets
import shutil
import subprocess
import sys
import threading
import webbrowser
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request

from secure_http import safe_urlopen as urlopen

from credential_store import CredentialStoreError, delete_credentials, load_credentials, save_credentials
from okx_client import OkxClient, OkxCredentials, OkxError

from tz_select import (
    TzSelectError,
    TzSelectRefreshing,
    fetch_free_package,
    tls_context,
    validate_package,
)


ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
CSRF_TOKEN = secrets.token_urlsafe(32)
STATE_LOCK = threading.RLock()
PAID_PACKAGES = {}
PAID_PACKAGE_PRODUCTS = {}
FREE_PACKAGES = {}
OKX_PREVIEWS = {}
OKX_SESSION = {"client": None, "summary": None, "position": None, "affiliate": None}

PAID_PRODUCTS = {
    "BTC": "https://api.tradingzones.app/v1/signals/BTC/4h",
    "ETH": "https://api.tradingzones.app/v1/signals/ETH/4h",
    "XRP": "https://api.tradingzones.app/v1/signals/XRP/4h",
    "ONDO": "https://api.tradingzones.app/v1/signals/ONDO/4h",
    "TZ-SELECT": "https://api.tradingzones.app/v1/signals/TZ-SELECT/4h",
}
BASE_NETWORK = "eip155:8453"
BASE_USDC = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"
PAY_TO = "0x449352D4B7A7928dBE64eec73B2427B7b3C98e81"
PAYMENT_AMOUNT_ATOMIC = "30000"
OFFICIAL_WALLET_URL = "https://www.coinbase.com/wallet/downloads"
OFFICIAL_WALLET_HELP = "https://help.coinbase.com/en/wallet/browser-extension/coinbase-wallet-extension"
OFFICIAL_CHROME_URL = "https://www.google.com/chrome/"
OFFICIAL_WALLET_EXTENSION = "https://chromewebstore.google.com/detail/coinbase-wallet-extension/hnfanknocfeofbddgcijnmhnfnkdnaad"
OKX_AFFILIATE_VERIFY_URL = "https://api.tradingzones.app/v1/partners/okx/verify"
OKX_AFFILIATE_JOIN_URL = "https://my.okx.com/join/40572160"
OKX_AFFILIATE_CODE = "40572160"
OFFICIAL_LINKS = {
    "chrome": OFFICIAL_CHROME_URL,
    "wallet": OFFICIAL_WALLET_URL,
    "help": OFFICIAL_WALLET_HELP,
    "extension": OFFICIAL_WALLET_EXTENSION,
    "okx_join": OKX_AFFILIATE_JOIN_URL,
}


def verify_okx_affiliate(main_uid: str) -> dict:
    """Sprawdza neutralny status afiliacji, nigdy nie wysyłając kluczy OKX."""
    uid = str(main_uid or "").strip()
    if not uid.isdigit() or not 6 <= len(uid) <= 24:
        return {
            "verified": False,
            "operational": False,
            "source": "missing_main_uid",
            "message": "OKX nie zwrócił poprawnego UID konta głównego.",
        }
    body = json.dumps({"main_uid": uid}, separators=(",", ":")).encode("utf-8")
    request = Request(
        OKX_AFFILIATE_VERIFY_URL,
        data=body,
        headers={
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "TradingZones-BOT/4.0",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=12, context=tls_context()) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        try:
            payload = json.loads(exc.read().decode("utf-8"))
            message = str(payload.get("error") or payload.get("message") or "")
        except (UnicodeDecodeError, json.JSONDecodeError):
            message = ""
        return {
            "verified": False,
            "operational": False,
            "source": "service_error",
            "message": message or f"Weryfikacja partnerstwa zwróciła HTTP {exc.code}.",
        }
    except (URLError, TimeoutError, OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        return {
            "verified": False,
            "operational": False,
            "source": "service_unavailable",
            "message": f"Nie udało się sprawdzić partnerstwa: {exc}",
        }

    if not isinstance(payload, dict):
        return {
            "verified": False,
            "operational": False,
            "source": "invalid_response",
            "message": "Usługa partnerstwa zwróciła niepoprawną odpowiedź.",
        }
    verified = payload.get("verified") is True
    if verified and (
        str(payload.get("affiliate_code") or "") != OKX_AFFILIATE_CODE
        or str(payload.get("join_url") or "") != OKX_AFFILIATE_JOIN_URL
    ):
        return {
            "verified": False,
            "operational": False,
            "source": "identity_mismatch",
            "message": "Odpowiedź partnerstwa nie zgadza się z oficjalną konfiguracją Trading Zones.",
        }
    return {
        "verified": verified,
        "operational": True,
        "source": str(payload.get("source") or ("verified" if verified else "not_invitee")),
        "partner": "Trading Zones × OKX",
        "join_url": OKX_AFFILIATE_JOIN_URL,
        "affiliate_code": OKX_AFFILIATE_CODE,
        "message": "" if verified else "Konto główne nie jest przypisane do linku partnerskiego Trading Zones.",
    }


def _find_chrome():
    candidates = []
    for name in ("google-chrome", "google-chrome-stable", "chrome", "chromium"):
        found = shutil.which(name)
        if found:
            candidates.append(found)
    if sys.platform == "win32":
        for root in (
            os.environ.get("LOCALAPPDATA"),
            os.environ.get("PROGRAMFILES"),
            os.environ.get("PROGRAMFILES(X86)"),
        ):
            if root:
                candidates.append(str(Path(root) / "Google" / "Chrome" / "Application" / "chrome.exe"))
    elif sys.platform == "darwin":
        candidates.append("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
    return next((path for path in candidates if Path(path).is_file()), None)


class BotHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC), **kwargs)

    def log_message(self, fmt, *args):
        print(f"[TZ BOT] {fmt % args}")

    def _json(self, status: int, payload: dict, extra_headers=None):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        for name, value in (extra_headers or {}).items():
            if value:
                self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    def _local_request_ok(self):
        allowed_hosts = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
        host = (self.headers.get("Host") or "").lower()
        if host not in allowed_hosts:
            return False
        origin = self.headers.get("Origin")
        # Other local ports are distinct browser origins, not this application.
        if origin and origin not in {f"http://{value}" for value in allowed_hosts}:
            return False
        return True

    def end_headers(self):
        # Applied to static HTML/JS too, not only JSON API responses.
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "frame-ancestors 'none'; base-uri 'none'; object-src 'none'")
        super().end_headers()

    def do_HEAD(self):
        if not self._local_request_ok():
            self.send_response(HTTPStatus.FORBIDDEN)
            self.end_headers()
            return
        super().do_HEAD()

    def list_directory(self, path):
        self.send_error(HTTPStatus.NOT_FOUND)
        return None

    def _csrf_ok(self):
        return secrets.compare_digest(self.headers.get("X-TZ-CSRF") or "", CSRF_TOKEN)

    def _body(self, maximum=65536):
        try:
            length = int(self.headers.get("Content-Length") or "0")
        except ValueError as exc:
            raise ValueError("Niepoprawny rozmiar żądania.") from exc
        if length < 0 or length > maximum:
            raise ValueError("Żądanie jest zbyt duże.")
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8")) if length else {}
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("Niepoprawny JSON.") from exc
        if not isinstance(payload, dict):
            raise ValueError("Oczekiwano obiektu JSON.")
        return payload

    @staticmethod
    def _credentials(payload):
        return OkxCredentials(
            api_key=str(payload.get("api_key") or "").strip(),
            secret_key=str(payload.get("secret_key") or "").strip(),
            passphrase=str(payload.get("passphrase") or ""),
            demo=False,
            region=str(payload.get("region") or "eea"),
        )

    @staticmethod
    def _public_summary(summary):
        return {
            "available_usdc": summary["available_usdc"],
            "equity_usdc": summary["equity_usdc"],
            "position_mode": summary["position_mode"],
            "account_level": summary["account_level"],
            "demo": summary["demo"],
            "region": summary["region"],
        }

    @staticmethod
    def _public_affiliate(affiliate):
        affiliate = affiliate or {}
        return {
            "verified": affiliate.get("verified") is True,
            "operational": affiliate.get("operational") is True,
            "source": str(affiliate.get("source") or "not_checked"),
            "partner": "Trading Zones × OKX",
            "join_url": OKX_AFFILIATE_JOIN_URL,
            "affiliate_code": OKX_AFFILIATE_CODE,
            "message": str(affiliate.get("message") or ""),
        }

    @staticmethod
    def _decode_payment_required(value):
        try:
            padded = value + "=" * (-len(value) % 4)
            return json.loads(base64.urlsafe_b64decode(padded).decode("utf-8"))
        except Exception as exc:
            raise TzSelectError("Serwer zwrócił niepoprawne wymagania płatności x402.") from exc

    @classmethod
    def _validate_payment_required(cls, value, expected_url):
        data = cls._decode_payment_required(value)
        resource = data.get("resource") or {}
        accepts = data.get("accepts") or []
        if data.get("x402Version") != 2 or resource.get("url") != expected_url:
            raise TzSelectError("Niezgodny zasób lub wersja płatności x402.")
        allowed = [
            item for item in accepts
            if str(item.get("scheme") or "") == "exact"
            and str(item.get("network") or "") == BASE_NETWORK
            and str(item.get("asset") or "").lower() == BASE_USDC.lower()
            and str(item.get("amount") or "") == PAYMENT_AMOUNT_ATOMIC
            and str(item.get("payTo") or "").lower() == PAY_TO.lower()
        ]
        if len(allowed) != 1:
            raise TzSelectError("Cena, sieć, token lub odbiorca płatności nie zgadza się z polityką bota.")
        return data

    def _paid_analysis(self, product):
        paid_url = PAID_PRODUCTS.get(product)
        if not paid_url:
            self._json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "Nieznany płatny produkt."})
            return
        if not self._csrf_ok():
            self._json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "Nieprawidłowy token sesji lokalnej."})
            return
        payment_signature = self.headers.get("PAYMENT-SIGNATURE")
        if payment_signature and len(payment_signature) > 65536:
            self._json(HTTPStatus.BAD_REQUEST, {"ok": False, "error": "Nagłówek płatności jest zbyt duży."})
            return
        headers = {
            "Accept": "application/json",
            "User-Agent": "TradingZones-BOT/4.0",
        }
        if payment_signature:
            headers["PAYMENT-SIGNATURE"] = payment_signature
        request = Request(paid_url, headers=headers)
        try:
            with urlopen(request, timeout=30, context=tls_context()) as response:
                status = response.status
                body = response.read()
                remote_headers = response.headers
        except HTTPError as exc:
            status = exc.code
            body = exc.read()
            remote_headers = exc.headers
        except (URLError, TimeoutError, OSError) as exc:
            self._json(HTTPStatus.BAD_GATEWAY, {"ok": False, "error": f"Błąd połączenia z API: {exc}"})
            return

        payment_required = remote_headers.get("PAYMENT-REQUIRED")
        payment_response = remote_headers.get("PAYMENT-RESPONSE")
        if status == HTTPStatus.PAYMENT_REQUIRED:
            try:
                self._validate_payment_required(payment_required or "", paid_url)
            except TzSelectError as exc:
                self._json(HTTPStatus.BAD_GATEWAY, {"ok": False, "error": str(exc)})
                return
            self._json(
                HTTPStatus.PAYMENT_REQUIRED,
                {"ok": False, "status": "payment_required"},
                {"PAYMENT-REQUIRED": payment_required},
            )
            return
        if status != HTTPStatus.OK:
            self._json(status, {"ok": False, "error": f"API zwróciło HTTP {status}."})
            return
        try:
            package = validate_package(json.loads(body.decode("utf-8")), expected_product=product)
        except (UnicodeDecodeError, json.JSONDecodeError, TzSelectError) as exc:
            self._json(HTTPStatus.BAD_GATEWAY, {"ok": False, "error": f"Zakupiony pakiet został zablokowany: {exc}"})
            return
        delivery_id = package.get("delivery_id") or secrets.token_urlsafe(18)
        package["delivery_id"] = delivery_id
        with STATE_LOCK:
            PAID_PACKAGES[delivery_id] = package
            PAID_PACKAGE_PRODUCTS[delivery_id] = product
        self._json(
            HTTPStatus.OK,
            {"ok": True, "status": "paid", "package": package},
            {"PAYMENT-RESPONSE": payment_response},
        )

    def do_GET(self):
        if not self._local_request_ok():
            self._json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "Żądanie spoza lokalnej aplikacji zostało zablokowane."})
            return
        path = urlparse(self.path).path
        if path == "/api/health":
            self._json(HTTPStatus.OK, {"ok": True, "version": "4.2"})
            return
        if path == "/api/config":
            self._json(HTTPStatus.OK, {
                "ok": True,
                "csrf_token": CSRF_TOKEN,
                "payment": {
                    "network": BASE_NETWORK,
                    "asset": BASE_USDC,
                    "amount_atomic": PAYMENT_AMOUNT_ATOMIC,
                    "price": "0.03 USDC",
                    "pay_to": PAY_TO,
                    "products": [
                        {"id": product, "resource": url, "price": "0.03 USDC"}
                        for product, url in PAID_PRODUCTS.items()
                    ],
                },
                "official_links": {
                    "chrome": OFFICIAL_CHROME_URL,
                    "wallet": OFFICIAL_WALLET_URL,
                    "help": OFFICIAL_WALLET_HELP,
                    "extension": OFFICIAL_WALLET_EXTENSION,
                    "okx_join": OKX_AFFILIATE_JOIN_URL,
                },
                "okx": {
                    "regions": ["eea", "global", "us"],
                    "default_region": "eea",
                    "default_demo": False,
                    "affiliate_code": OKX_AFFILIATE_CODE,
                    "join_url": OKX_AFFILIATE_JOIN_URL,
                },
            })
            return
        if path == "/api/tz-select/free":
            try:
                package = fetch_free_package()
            except TzSelectRefreshing as exc:
                self._json(
                    HTTPStatus.SERVICE_UNAVAILABLE,
                    {"ok": False, "status": "refreshing", "error": str(exc), "retry_after": exc.retry_after},
                )
                return
            except TzSelectError as exc:
                self._json(
                    HTTPStatus.BAD_GATEWAY,
                    {"ok": False, "status": "blocked", "error": str(exc)},
                )
                return
            package["delivery_id"] = "tzfree_current"
            with STATE_LOCK:
                FREE_PACKAGES.clear()
                FREE_PACKAGES[package["delivery_id"]] = package
            self._json(HTTPStatus.OK, {"ok": True, "status": "available", "package": package})
            return
        if path in {"/api/session/packages", "/api/session/paid-packages"}:
            with STATE_LOCK:
                packages = [
                    {"source": "paid", "product": PAID_PACKAGE_PRODUCTS.get(delivery_id, package.get("symbol")), "package": package}
                    for delivery_id, package in PAID_PACKAGES.items()
                ]
                packages.extend(
                    {"source": "free", "product": "TZ-SELECT", "package": package}
                    for package in FREE_PACKAGES.values()
                )
            self._json(HTTPStatus.OK, {"ok": True, "packages": packages})
            return
        if path.startswith("/api/x402/"):
            product = path.removeprefix("/api/x402/").upper()
            self._paid_analysis(product)
            return
        if path == "/":
            self.path = "/index.html"
        super().do_GET()

    def do_POST(self):
        if not self._local_request_ok() or not self._csrf_ok():
            self._json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "Żądanie spoza lokalnej aplikacji zostało zablokowane."})
            return
        path = urlparse(self.path).path
        try:
            payload = self._body()
            if path == "/api/open-chrome":
                self._open_chrome(payload)
            elif path == "/api/okx/connect":
                self._okx_connect(payload)
            elif path == "/api/okx/save":
                self._okx_save(payload)
            elif path == "/api/okx/load":
                self._okx_load()
            elif path == "/api/okx/affiliate/verify":
                self._okx_verify_affiliate()
            elif path == "/api/okx/delete-saved":
                self._json(HTTPStatus.OK, {"ok": True, "deleted": delete_credentials()})
            elif path == "/api/okx/disconnect":
                with STATE_LOCK:
                    OKX_SESSION.update({"client": None, "summary": None, "position": None, "affiliate": None})
                    OKX_PREVIEWS.clear()
                self._json(HTTPStatus.OK, {"ok": True})
            elif path == "/api/okx/preview":
                self._okx_preview(payload)
            elif path == "/api/okx/order":
                self._okx_order(payload)
            elif path == "/api/okx/status":
                self._okx_status()
            elif path == "/api/okx/close":
                self._okx_close(payload)
            else:
                self._json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "Nieznana operacja."})
        except (ValueError, OkxError, CredentialStoreError, InvalidOperation) as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"ok": False, "error": str(exc)})

    def _open_chrome(self, payload):
        target = str(payload.get("target") or "local")
        local_url = f"http://127.0.0.1:{self.server.server_port}"
        url = local_url if target == "local" else OFFICIAL_LINKS.get(target)
        if not url:
            raise ValueError("Nieznany oficjalny link.")
        chrome = _find_chrome()
        if not chrome:
            if target == "chrome":
                webbrowser.open(OFFICIAL_CHROME_URL)
                self._json(HTTPStatus.OK, {"ok": True, "opened": OFFICIAL_CHROME_URL, "fallback": True})
                return
            self._json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "Google Chrome nie został znaleziony na tym komputerze."})
            return
        try:
            subprocess.Popen([chrome, url], close_fds=True)
        except OSError as exc:
            raise ValueError(f"Nie udało się uruchomić Chrome: {exc}") from exc
        self._json(HTTPStatus.OK, {"ok": True, "opened": url})

    def _okx_connect(self, payload, loaded=False):
        credentials = self._credentials(payload)
        client = OkxClient(credentials)
        summary = client.account_summary()
        affiliate = verify_okx_affiliate(summary.get("main_uid"))
        with STATE_LOCK:
            OKX_SESSION.update({"client": client, "summary": summary, "position": None, "affiliate": affiliate})
            OKX_PREVIEWS.clear()
        self._json(HTTPStatus.OK, {
            "ok": True,
            "loaded": loaded,
            "account": self._public_summary(summary),
            "affiliate": self._public_affiliate(affiliate),
        })

    def _okx_save(self, payload):
        credentials = self._credentials(payload)
        save_credentials({
            "api_key": credentials.api_key,
            "secret_key": credentials.secret_key,
            "passphrase": credentials.passphrase,
            "demo": credentials.demo,
            "region": credentials.region,
        })
        self._json(HTTPStatus.OK, {"ok": True, "saved": True})

    def _okx_load(self):
        self._okx_connect(load_credentials(), loaded=True)

    @staticmethod
    def _current_client():
        with STATE_LOCK:
            client = OKX_SESSION.get("client")
        if not client:
            raise OkxError("Najpierw połącz konto OKX.")
        return client

    @staticmethod
    def _refresh_affiliate_verification():
        with STATE_LOCK:
            summary = OKX_SESSION.get("summary") or {}
        if not summary:
            raise OkxError("Najpierw połącz konto OKX.")
        affiliate = verify_okx_affiliate(summary.get("main_uid"))
        with STATE_LOCK:
            OKX_SESSION["affiliate"] = affiliate
        return affiliate

    def _require_verified_affiliate(self):
        affiliate = self._refresh_affiliate_verification()
        if affiliate.get("verified") is not True:
            if affiliate.get("operational") is not True:
                raise OkxError("Nie udało się potwierdzić partnerstwa OKX. Spróbuj ponownie za chwilę.")
            raise OkxError(
                "Automatyczne zlecenia są dostępne dla kont zarejestrowanych przez oficjalny link Trading Zones × OKX. "
                "Analizy nadal możesz kupować i rozgrywać ręcznie."
            )
        return affiliate

    def _okx_verify_affiliate(self):
        affiliate = self._refresh_affiliate_verification()
        self._json(HTTPStatus.OK, {"ok": True, "affiliate": self._public_affiliate(affiliate)})

    def _okx_preview(self, payload):
        self._require_verified_affiliate()
        delivery_id = str(payload.get("delivery_id") or "")
        with STATE_LOCK:
            package = PAID_PACKAGES.get(delivery_id) or FREE_PACKAGES.get(delivery_id)
        if not package:
            raise OkxError("Nie znaleziono zweryfikowanego pakietu w tej sesji.")
        try:
            margin = Decimal(str(payload.get("margin_usdc", payload.get("margin"))))
            leverage = int(payload.get("leverage"))
        except (InvalidOperation, ValueError, TypeError) as exc:
            raise OkxError("Podaj poprawny margin i dźwignię.") from exc
        client = self._current_client()
        preview = client.preview(package, margin, leverage)
        token = secrets.token_urlsafe(32)
        preview["delivery_id"] = delivery_id
        preview["expires_at"] = (datetime.now(timezone.utc).timestamp() + 60)
        with STATE_LOCK:
            OKX_PREVIEWS.clear()
            OKX_PREVIEWS[token] = preview
        self._json(HTTPStatus.OK, {"ok": True, "confirmation_token": token, "preview": preview})

    def _okx_order(self, payload):
        self._require_verified_affiliate()
        token = str(payload.get("confirmation_token") or "")
        with STATE_LOCK:
            preview = OKX_PREVIEWS.pop(token, None)
            delivery_id = (preview or {}).get("delivery_id")
            package = PAID_PACKAGES.get(delivery_id) or FREE_PACKAGES.get(delivery_id)
        if not preview or not package or datetime.now(timezone.utc).timestamp() >= preview["expires_at"]:
            raise OkxError("Potwierdzenie wygasło. Wygeneruj nowy podgląd zlecenia.")
        client = self._current_client()
        # Powtórna walidacja salda, ceny, pozycji i kontraktu tuż przed mutacją.
        refreshed = client.preview(package, Decimal(preview["margin_usdc"]), int(preview["leverage"]))
        for field in ("inst_id", "direction", "contracts", "stop_loss", "take_profit"):
            if refreshed.get(field) != preview.get(field):
                raise OkxError("Warunki rynku zmieniły się. Sprawdź nowy podgląd przed zleceniem.")
        result = client.place_order(refreshed)
        position = {**result, **refreshed}
        summary = client.account_summary()
        with STATE_LOCK:
            OKX_SESSION["position"] = position
            OKX_SESSION["summary"] = summary
        self._json(HTTPStatus.OK, {
            "ok": True,
            "order": result,
            "position": position,
            "account": self._public_summary(summary),
        })

    def _okx_status(self):
        client = self._current_client()
        with STATE_LOCK:
            tracked = OKX_SESSION.get("position")
        if not tracked:
            self._json(HTTPStatus.OK, {"ok": True, "position": None})
            return
        rows = client.positions(tracked["inst_id"])
        live = next((row for row in rows if Decimal(str(row.get("pos") or "0")) != 0), None)
        self._json(HTTPStatus.OK, {"ok": True, "position": live, "tracked": tracked})

    def _okx_close(self, payload):
        if str(payload.get("confirm") or "") != "ZAMKNIJ":
            raise OkxError("Zamknięcie pozycji wymaga jawnego potwierdzenia.")
        client = self._current_client()
        with STATE_LOCK:
            tracked = OKX_SESSION.get("position")
        if not tracked:
            raise OkxError("Brak pozycji utworzonej przez tę sesję bota.")
        result = client.close_position(tracked["inst_id"], tracked["position_mode"], tracked["direction"])
        with STATE_LOCK:
            OKX_SESSION["position"] = None
        self._json(HTTPStatus.OK, {"ok": True, "result": result})


def main():
    host = "127.0.0.1"
    preferred = int(os.environ.get("TZ_BOT_PORT", "8765"))
    server = None
    for port in range(preferred, preferred + 20):
        try:
            server = ThreadingHTTPServer((host, port), BotHandler)
            break
        except OSError:
            continue
    if server is None:
        raise RuntimeError("Nie znaleziono wolnego portu lokalnego.")

    url = f"http://{host}:{server.server_port}"
    print(f"TradingZones-BOT v4.2 działa lokalnie: {url}")
    print("Zamknij to okno lub naciśnij Ctrl+C, aby wyłączyć aplikację.")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
