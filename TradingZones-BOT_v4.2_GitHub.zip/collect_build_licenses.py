"""Collect installed Python distribution licenses alongside a built EXE."""
import importlib.metadata
import shutil
import sys
from pathlib import Path


def main():
    target = Path('dist') / 'python_licenses'
    target.mkdir(parents=True, exist_ok=True)
    for distribution in importlib.metadata.distributions():
        name = distribution.metadata.get('Name', 'unknown').replace('/', '_')
        for entry in distribution.files or []:
            filename = Path(str(entry)).name.lower()
            if not filename.startswith(('license', 'licence', 'copying', 'notice')):
                continue
            if filename.endswith(('.py', '.pyc')):
                continue
            source = Path(distribution.locate_file(entry))
            if not source.is_file() or source.stat().st_size > 2_000_000:
                continue
            destination = target / name / Path(str(entry)).name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
    for filename in ('LICENSE.txt', 'LICENSE'):
        source = Path(sys.base_prefix) / filename
        if source.is_file():
            shutil.copyfile(source, target / 'Python-LICENSE.txt')
            break


if __name__ == '__main__':
    main()
