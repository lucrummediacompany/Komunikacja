from __future__ import annotations

import ctypes
import json
import os
import sys
from ctypes import wintypes
from pathlib import Path


class CredentialStoreError(RuntimeError):
    pass


class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _path() -> Path:
    root = os.environ.get("LOCALAPPDATA")
    if not root:
        raise CredentialStoreError("Brak katalogu LOCALAPPDATA.")
    return Path(root) / "TradingZones-BOT" / "okx_credentials.bin"


def _blob(data: bytes):
    buffer = ctypes.create_string_buffer(data)
    return DATA_BLOB(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_char))), buffer


def _crypt(data: bytes, protect: bool) -> bytes:
    if sys.platform != "win32":
        raise CredentialStoreError("Szyfrowany zapis danych API jest dostępny wyłącznie w Windows.")
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    crypt32.CryptProtectData.restype = wintypes.BOOL
    crypt32.CryptUnprotectData.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [wintypes.HLOCAL]
    kernel32.LocalFree.restype = wintypes.HLOCAL
    source, source_buffer = _blob(data)
    output = DATA_BLOB()
    description = "TradingZones-BOT OKX" if protect else None
    func = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    if protect:
        ok = func(ctypes.byref(source), description, None, None, None, 0, ctypes.byref(output))
    else:
        ok = func(ctypes.byref(source), None, None, None, None, 0, ctypes.byref(output))
    if not ok:
        raise CredentialStoreError("Windows nie mógł zaszyfrować lub odszyfrować danych API.")
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        kernel32.LocalFree(ctypes.cast(output.pbData, wintypes.HLOCAL))
        del source_buffer


def save_credentials(payload: dict) -> None:
    allowed = {key: payload[key] for key in ("api_key", "secret_key", "passphrase", "demo", "region")}
    encrypted = _crypt(json.dumps(allowed, separators=(",", ":")).encode("utf-8"), True)
    path = _path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(encrypted)


def load_credentials() -> dict:
    path = _path()
    if not path.is_file():
        raise CredentialStoreError("Nie znaleziono zapisanych danych API.")
    try:
        payload = json.loads(_crypt(path.read_bytes(), False).decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise CredentialStoreError("Zapisane dane API są uszkodzone.") from exc
    return payload


def delete_credentials() -> bool:
    path = _path()
    if not path.exists():
        return False
    path.unlink()
    return True
