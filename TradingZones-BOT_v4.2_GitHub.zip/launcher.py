"""Windows EXE entry point. Console stays visible; no embedded user credentials."""
import sys
from pathlib import Path


def self_test():
    from credential_store import _crypt
    from tz_select import tls_context
    root = Path(__file__).resolve().parent
    for name in ('index.html', 'legal.html', 'styles.css', 'desktop-v4.css', 'app.bundle.js', 'okx-partner-compact.png'):
        if not (root / 'static' / name).is_file():
            raise RuntimeError('Missing bundled asset: ' + name)
    tls_context()
    if sys.platform == 'win32':
        dummy = b'TradingZones build self-test (not a credential)'
        if _crypt(_crypt(dummy, True), False) != dummy:
            raise RuntimeError('DPAPI self-test failed')
    print('TradingZones-BOT v4.2: assets, TLS context and platform storage self-test OK')


def main():
    if '--self-test' in sys.argv[1:]:
        self_test()
        return
    import app
    app.main()


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        # Do not print exception values, request objects or credential representations.
        print('TradingZones-BOT could not start. Error type: ' + type(error).__name__)
        if '--self-test' not in sys.argv[1:]:
            try:
                input('Press Enter to close this window...')
            except EOFError:
                pass
        sys.exit(1)
