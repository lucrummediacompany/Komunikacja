from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN, InvalidOperation
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request

from secure_http import safe_urlopen as urlopen

from tz_select import tls_context


OKX_DOMAINS = {
    "eea": "https://eea.okx.com",
    "global": "https://www.okx.com",
    "us": "https://us.okx.com",
}
ALLOWED_SYMBOLS = {"BTC", "ETH", "XRP", "ONDO"}
ALLOWED_LEVERAGES = {1, 2, 3, 4, 5, 10}
OKX_XPERP_FAMILIES = {
    "BTC": "BTC-USD_UM_XPERP",
    "ETH": "ETH-USD_UM_XPERP",
    "XRP": "XRP-USD_UM_XPERP",
    "ONDO": "ONDO-USD_UM_XPERP",
}


class OkxError(RuntimeError):
    pass


def _decimal(value: Any, label: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise OkxError(f"Niepoprawna wartość {label}.") from exc
    if not result.is_finite():
        raise OkxError(f"Niepoprawna wartość {label}.")
    return result


def decimal_text(value: Decimal) -> str:
    return format(value.normalize(), "f")


@dataclass(frozen=True)
class OkxCredentials:
    api_key: str = field(repr=False)
    secret_key: str = field(repr=False)
    passphrase: str = field(repr=False)
    demo: bool = False
    region: str = "eea"

    def __post_init__(self):
        if not self.api_key.strip() or not self.secret_key.strip() or not self.passphrase:
            raise OkxError("Wpisz API Key, Secret Key i Passphrase.")
        if self.region not in OKX_DOMAINS:
            raise OkxError("Nieobsługiwany region konta OKX.")


class OkxClient:
    def __init__(self, credentials: OkxCredentials, timeout: int = 20):
        self.credentials = credentials
        self.base_url = OKX_DOMAINS[credentials.region]
        self.timeout = timeout

    @staticmethod
    def _timestamp() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")

    def _request(self, method: str, path: str, params: dict | None = None, body: dict | None = None, private: bool = True):
        method = method.upper()
        query = urlencode(params or {})
        request_path = path + (f"?{query}" if query else "")
        body_text = json.dumps(body, separators=(",", ":"), ensure_ascii=False) if body is not None else ""
        headers = {"Accept": "application/json", "User-Agent": "TradingZones-BOT/4.0"}
        if body is not None:
            headers["Content-Type"] = "application/json"
        if private:
            timestamp = self._timestamp()
            prehash = f"{timestamp}{method}{request_path}{body_text}".encode()
            signature = base64.b64encode(
                hmac.new(self.credentials.secret_key.encode(), prehash, hashlib.sha256).digest()
            ).decode()
            headers.update({
                "OK-ACCESS-KEY": self.credentials.api_key,
                "OK-ACCESS-SIGN": signature,
                "OK-ACCESS-TIMESTAMP": timestamp,
                "OK-ACCESS-PASSPHRASE": self.credentials.passphrase,
            })
            if self.credentials.demo:
                headers["x-simulated-trading"] = "1"
        request = Request(
            self.base_url + request_path,
            data=body_text.encode("utf-8") if body is not None else None,
            headers=headers,
            method=method,
        )
        try:
            with urlopen(request, timeout=self.timeout, context=tls_context()) as response:
                raw = response.read()
        except HTTPError as exc:
            raw = exc.read()
            try:
                message = json.loads(raw.decode()).get("msg")
            except Exception:
                message = None
            raise OkxError(message or f"OKX zwrócił HTTP {exc.code}.") from exc
        except (URLError, TimeoutError, OSError) as exc:
            raise OkxError(f"Nie udało się połączyć z OKX: {exc}") from exc
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise OkxError("OKX zwrócił niepoprawną odpowiedź JSON.") from exc
        if str(payload.get("code")) != "0":
            raise OkxError(str(payload.get("msg") or f"Błąd OKX {payload.get('code')}"))
        return payload.get("data") or []

    def account_summary(self) -> dict:
        config = self._request("GET", "/api/v5/account/config")
        balances = self._request("GET", "/api/v5/account/balance", {"ccy": "USDC"})
        account = config[0] if config else {}
        balance = balances[0] if balances else {}
        details = (balance.get("details") or [])
        usdc = next((row for row in details if str(row.get("ccy") or "").upper() == "USDC"), {})
        source = usdc or balance
        return {
            # Dla futures istotne jest wolne zabezpieczenie availEq. availBal
            # pozostaje fallbackiem zgodnym z MASTER v14.
            "available_usdc": str(source.get("availEq") or source.get("availBal") or "0"),
            "equity_usdc": str(source.get("eq") or source.get("cashBal") or "0"),
            "position_mode": str(account.get("posMode") or ""),
            "account_level": str(account.get("acctLv") or ""),
            "uid": str(account.get("uid") or ""),
            "main_uid": str(account.get("mainUid") or account.get("uid") or ""),
            "demo": self.credentials.demo,
            "region": self.credentials.region,
        }

    def instrument(self, symbol: str) -> dict:
        symbol = symbol.upper()
        if symbol not in ALLOWED_SYMBOLS:
            raise OkxError("Nieobsługiwany symbol OKX.")
        family = OKX_XPERP_FAMILIES[symbol]
        rows = self._request(
            "GET",
            "/api/v5/public/instruments",
            {"instType": "FUTURES", "instFamily": family},
            private=False,
        )
        now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
        live = [
            row for row in rows
            if row.get("state") == "live"
            and (row.get("ruleType") == "xperp" or "XPERP" in str(row.get("instId") or "").upper())
            and str(row.get("settleCcy") or "").upper() in {"USD", "USDC", "USDG"}
            and int(row.get("expTime") or 0) > now_ms
        ]
        live.sort(key=lambda row: int(row.get("expTime") or 0), reverse=True)
        instrument = live[0] if live else None
        if not instrument:
            raise OkxError(f"Brak aktywnego kontraktu X-Perp dla rodziny {family}.")
        inst_id = str(instrument.get("instId") or "")
        if instrument.get("ctType") != "linear":
            raise OkxError(f"Instrument {inst_id} nie jest aktywnym kontraktem liniowym.")
        if str(instrument.get("ctValCcy") or "").upper() != symbol:
            raise OkxError(f"Nieobsługiwana waluta wartości kontraktu {inst_id}.")
        account_rows = self._request(
            "GET",
            "/api/v5/account/instruments",
            {"instType": "FUTURES", "instId": inst_id},
        )
        if not any(row.get("instId") == inst_id and row.get("state") == "live" for row in account_rows):
            raise OkxError(f"Kontrakt {inst_id} nie jest dostępny na tym koncie OKX.")
        return instrument

    def mark_price(self, inst_id: str) -> Decimal:
        rows = self._request("GET", "/api/v5/public/mark-price", {"instType": "FUTURES", "instId": inst_id}, private=False)
        if not rows:
            raise OkxError("Brak ceny mark dla instrumentu.")
        price = _decimal(rows[0].get("markPx"), "mark price")
        if price <= 0:
            raise OkxError("Niepoprawna cena mark.")
        return price

    def positions(self, inst_id: str) -> list[dict]:
        rows = self._request("GET", "/api/v5/account/positions", {"instId": inst_id})
        return [row for row in rows if _decimal(row.get("pos") or "0", "pozycja") != 0]

    def leverage_info(self, inst_id: str, margin_mode: str = "cross") -> list[dict]:
        return self._request("GET", "/api/v5/account/leverage-info", {
            "instId": inst_id,
            "mgnMode": margin_mode,
        })

    def pending_orders(self, inst_id: str) -> list[dict]:
        return self._request("GET", "/api/v5/trade/orders-pending", {"instType": "FUTURES", "instId": inst_id})

    @staticmethod
    def contract_size(instrument: dict, mark_price: Decimal, notional: Decimal) -> tuple[Decimal, Decimal]:
        ct_val = _decimal(instrument.get("ctVal"), "ctVal")
        ct_mult = _decimal(instrument.get("ctMult") or "1", "ctMult")
        lot = _decimal(instrument.get("lotSz"), "lotSz")
        minimum = _decimal(instrument.get("minSz"), "minSz")
        if min(ct_val, ct_mult, lot, minimum, mark_price, notional) <= 0:
            raise OkxError("Niepoprawne parametry kontraktu OKX.")
        per_contract = ct_val * ct_mult * mark_price
        raw = notional / per_contract
        contracts = (raw / lot).to_integral_value(rounding=ROUND_DOWN) * lot
        if contracts < minimum:
            raise OkxError(f"Kwota jest za mała. Minimum dla tego kontraktu to {decimal_text(minimum)} kontraktów.")
        actual_notional = contracts * per_contract
        return contracts, actual_notional

    def preview(self, package: dict, margin: Decimal, leverage: int) -> dict:
        if package.get("action") != "TRADE" or package.get("tradable") is not True:
            raise OkxError("Tylko opłacony pakiet TRADE może utworzyć zlecenie.")
        valid_until = datetime.fromisoformat(str(package["valid_until"]).replace("Z", "+00:00"))
        if datetime.now(timezone.utc) >= valid_until:
            raise OkxError("Analiza wygasła. Pobierz nowy pakiet przed zleceniem.")
        if margin <= 0 or leverage not in ALLOWED_LEVERAGES:
            raise OkxError("Podaj dodatni margin i wybierz dźwignię z bezpiecznej listy bota.")
        summary = self.account_summary()
        available = _decimal(summary["available_usdc"], "dostępne saldo")
        if margin > available:
            raise OkxError("Wybrany margin przekracza aktualnie dostępne saldo USDC.")
        instrument = self.instrument(package["symbol"])
        max_leverage = _decimal(instrument.get("lever") or "0", "maksymalna dźwignia")
        if Decimal(leverage) > max_leverage:
            raise OkxError(f"Wybrana dźwignia przekracza limit instrumentu: {decimal_text(max_leverage)}x.")
        inst_id = instrument["instId"]
        if self.positions(inst_id):
            raise OkxError("Na tym instrumencie istnieje już pozycja. Nowe wejście zostało zablokowane.")
        if self.pending_orders(inst_id):
            raise OkxError("Na tym instrumencie istnieją oczekujące zlecenia. Nowe wejście zostało zablokowane.")
        mark = self.mark_price(inst_id)
        sl = _decimal(package.get("sl_lq"), "SL LQ")
        tp = _decimal(package.get("tp_lq"), "TP LQ")
        direction = package.get("direction")
        geometry_ok = (direction == "LONG" and sl < mark < tp) or (direction == "SHORT" and tp < mark < sl)
        if not geometry_ok:
            raise OkxError("Bieżąca analiza już się rozegrała. Pobierz nową analizę.")
        notional = margin * Decimal(leverage)
        contracts, actual_notional = self.contract_size(instrument, mark, notional)
        return {
            "inst_id": inst_id,
            "symbol": package["symbol"],
            "direction": direction,
            "side": "buy" if direction == "LONG" else "sell",
            "position_mode": summary["position_mode"],
            "margin_mode": "cross",
            "margin_usdc": decimal_text(margin),
            "leverage": leverage,
            "max_leverage": decimal_text(max_leverage),
            "requested_notional_usdc": decimal_text(notional),
            "actual_notional_usdc": decimal_text(actual_notional),
            "contracts": decimal_text(contracts),
            "mark_price": decimal_text(mark),
            "stop_loss": decimal_text(sl),
            "take_profit": decimal_text(tp),
            "valid_until": package["valid_until"],
            "delivery_id": package["delivery_id"],
            "demo": self.credentials.demo,
            "region": self.credentials.region,
        }

    def place_order(self, preview: dict) -> dict:
        position_mode = preview["position_mode"]
        if position_mode not in {"net_mode", "long_short_mode"}:
            raise OkxError("Nieobsługiwany tryb pozycji OKX.")
        pos_side = "net" if position_mode == "net_mode" else preview["direction"].lower()
        sides = ("long", "short") if position_mode == "long_short_mode" else ("",)
        for side in sides:
            self._request("POST", "/api/v5/account/set-leverage", body={
                "instId": preview["inst_id"],
                "lever": str(preview["leverage"]),
                "mgnMode": "cross",
                **({"posSide": side} if side else {}),
            })
        leverage_rows = [row for row in self.leverage_info(preview["inst_id"]) if row.get("instId") == preview["inst_id"]]
        required_sides = set(sides) - {""}
        actual_sides = {str(row.get("posSide") or "") for row in leverage_rows}
        if required_sides and not required_sides.issubset(actual_sides):
            raise OkxError("OKX nie potwierdził dźwigni dla obu stron cross. Zlecenie zablokowane.")
        target = Decimal(str(preview["leverage"]))
        checked = [row for row in leverage_rows if not required_sides or row.get("posSide") in required_sides]
        if not checked or any(_decimal(row.get("lever"), "dźwignia OKX") != target for row in checked):
            raise OkxError("Odczyt zwrotny OKX nie potwierdził wybranej dźwigni. Zlecenie zablokowane.")
        client_id = "tz" + secrets.token_hex(10)
        body = {
            "instId": preview["inst_id"],
            "tdMode": "cross",
            "clOrdId": client_id,
            "side": preview["side"],
            "posSide": pos_side,
            "ordType": "market",
            "sz": preview["contracts"],
            "attachAlgoOrds": [{
                "tpTriggerPx": preview["take_profit"],
                "tpOrdPx": preview["take_profit"],
                "tpTriggerPxType": "mark",
                "slTriggerPx": preview["stop_loss"],
                "slOrdPx": preview["stop_loss"],
                "slTriggerPxType": "mark",
            }],
        }
        rows = self._request("POST", "/api/v5/trade/order", body=body)
        result = rows[0] if rows else {}
        if str(result.get("sCode") or "0") != "0" or not result.get("ordId"):
            raise OkxError(str(result.get("sMsg") or "OKX nie potwierdził przyjęcia zlecenia."))
        return {"order_id": result["ordId"], "client_order_id": client_id, "inst_id": preview["inst_id"]}

    def close_position(self, inst_id: str, position_mode: str, direction: str) -> dict:
        body = {"instId": inst_id, "mgnMode": "cross", "autoCxl": True}
        if position_mode == "long_short_mode":
            body["posSide"] = direction.lower()
        rows = self._request("POST", "/api/v5/trade/close-position", body=body)
        result = rows[0] if rows else {}
        if str(result.get("sCode") or "0") != "0":
            raise OkxError(str(result.get("sMsg") or "OKX nie potwierdził zamknięcia pozycji."))
        return {"inst_id": inst_id, "closed": True}
