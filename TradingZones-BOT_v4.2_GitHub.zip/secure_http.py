"""HTTPS transport for fixed API destinations. Never forward credentials by redirect."""
from urllib.parse import urlparse
from urllib.request import HTTPRedirectHandler, HTTPSHandler, Request, build_opener


class NoRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # urllib otherwise copies custom OKX / x402 headers to a redirected host.
        return None


def safe_urlopen(request, *, timeout, context):
    url = request.full_url if isinstance(request, Request) else str(request)
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Połączenia z API wymagają poprawnego adresu HTTPS.")
    opener = build_opener(NoRedirectHandler(), HTTPSHandler(context=context))
    return opener.open(request, timeout=timeout)
