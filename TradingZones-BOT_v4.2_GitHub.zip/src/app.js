import { createPublicClient, createWalletClient, custom, formatUnits } from "viem";
import { base } from "viem/chains";
import { x402Client } from "@x402/core/client";
import { ExactEvmScheme } from "@x402/evm/exact/client";
import { wrapFetchWithPayment } from "@x402/fetch";

const BASE_CHAIN_ID = "0x2105";
const BASE_NETWORK = "eip155:8453";
const BASE_USDC = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913";
const PAY_TO = "0x449352D4B7A7928dBE64eec73B2427B7b3C98e81";
const PAYMENT_AMOUNT = "30000";
const OFFICIAL_LINKS = Object.freeze({
  chrome: "https://www.google.com/chrome/",
  wallet: "https://www.coinbase.com/wallet/downloads",
  help: "https://help.coinbase.com/en/wallet/browser-extension/coinbase-wallet-extension",
  extension: "https://chromewebstore.google.com/detail/coinbase-wallet-extension/hnfanknocfeofbddgcijnmhnfnkdnaad",
  okx_join: "https://my.okx.com/join/40572160",
});
const PRODUCT_IDS = new Set(["BTC", "ETH", "XRP", "ONDO", "TZ-SELECT"]);
const USDC_ABI = [{
  type: "function",
  name: "balanceOf",
  stateMutability: "view",
  inputs: [{ name: "account", type: "address" }],
  outputs: [{ name: "balance", type: "uint256" }],
}];

const state = {
  config: null,
  provider: null,
  account: null,
  walletName: "",
  paidFetch: null,
  countdownTimer: null,
  selectedPackage: null,
  sessionPackages: new Map(),
  selectedPackageId: null,
  okxAccount: null,
  okxAffiliate: null,
  okxCredentialsLoaded: false,
  packageExpiryTimers: new Map(),
  confirmationToken: null,
  orderPreview: null,
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const isGoogleChrome = () => {
  const ua = navigator.userAgent;
  return /Chrome\//.test(ua) && !/(Edg|OPR)\//.test(ua) && !navigator.brave;
};

const shortAddress = (address) => address ? `${address.slice(0, 6)}…${address.slice(-4)}` : "—";
const price = (value, symbol = "") => {
  if (value == null) return "—";
  const digits = /^(BTC|ETH)(?:$|-)/.test(symbol) ? 2 : (symbol ? 4 : (Math.abs(value) < 10 ? 4 : 2));
  return new Intl.NumberFormat("pl-PL", { maximumFractionDigits: digits }).format(value);
};
const dateTime = (value) => value ? new Date(value).toLocaleString("pl-PL") : "—";
const valueText = (value) => {
  if (value == null || value === "") return "—";
  if (typeof value === "number") return Number.isInteger(value) ? String(value) : value.toFixed(2);
  if (typeof value === "boolean") return value ? "TAK" : "NIE";
  return String(value);
};

function switchTab(name) {
  const targets = { free: "#tabFree", base: "#tabBase", okx: "#tabOkx" };
  if (!targets[name]) return;
  for (const [key, selector] of Object.entries(targets)) {
    const active = key === name;
    const panel = $(selector);
    panel.hidden = !active;
    panel.classList.toggle("active", active);
    const tab = $(`[data-tab="${key}"]`);
    tab.classList.toggle("active", active);
    tab.setAttribute("aria-selected", String(active));
  }
}

function setStatus(kind, text) {
  const node = $("#status");
  node.className = `status ${kind}`;
  node.textContent = text;
}

function setProductButtons(enabled) {
  $$(".product-button").forEach((button) => { button.disabled = !enabled; });
}

function startCountdown(validUntil) {
  if (state.countdownTimer) clearInterval(state.countdownTimer);
  const node = $("#countdown");
  const render = () => {
    const seconds = Math.max(0, Math.floor((new Date(validUntil).getTime() - Date.now()) / 1000));
    const h = String(Math.floor(seconds / 3600)).padStart(2, "0");
    const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    node.textContent = seconds ? `pozostało ${h}:${m}:${s}` : "analiza wygasła";
    if (!seconds) {
      const gate = $("#tradeGate");
      gate.className = "gate blocked";
      gate.textContent = "⛔ Analiza wygasła — pobierz nowy cykl przed zleceniem.";
    }
  };
  render();
  state.countdownTimer = setInterval(render, 1000);
}

function renderCore(pkg, paid = false, product = null) {
  $("#result").classList.remove("hidden");
  const isTrade = pkg.action === "TRADE";
  const badge = $("#actionBadge");
  badge.textContent = pkg.action;
  badge.className = `badge${isTrade ? "" : " no-trade"}`;
  $("#symbol").textContent = pkg.symbol;
  $("#direction").textContent = pkg.direction;
  $("#context").textContent = pkg.context?.message || pkg.reason || "—";
  $("#strength").textContent = pkg.setup_strength_score == null ? "—" : `${pkg.setup_strength_score.toFixed(2)}/100`;
  $("#entry").textContent = price(pkg.entry_reference, pkg.symbol);
  $("#sl").textContent = price(pkg.sl_lq, pkg.symbol);
  $("#tp").textContent = price(pkg.tp_lq, pkg.symbol);
  $("#validUntil").textContent = dateTime(pkg.valid_until);
  const gate = $("#tradeGate");
  gate.className = `gate ${isTrade ? "ready" : "blocked"}`;
  gate.textContent = isTrade
    ? `✓ Pakiet ${paid ? "opłacony, " : ""}kompletny i aktualny.${paid ? " Może zostać użyty w module OKX." : ""}`
    : "⏸ Analiza zwróciła NO_TRADE. Moduł zlecenia pozostanie zablokowany.";
  startCountdown(pkg.valid_until);
  setOkxPackage(pkg, paid ? (product || pkg.symbol) : "TZ-SELECT", paid ? "paid" : "free");
}

function detailItem(label, value) {
  const item = document.createElement("div");
  item.className = "detail-item";
  const name = document.createElement("span");
  name.textContent = label;
  const content = document.createElement("b");
  content.textContent = valueText(value);
  item.append(name, content);
  return item;
}

function renderDetails(container, rows) {
  container.replaceChildren(...rows.map(([label, value]) => detailItem(label, value)));
}

const INDICATOR_NAMES = {
  ch: "CHANNEL",
  rsi: "RSI",
  macd: "MACD",
  bolli: "BOLLINGER",
  stoch: "STOCHASTIC",
  taker: "TAKER BUY / SELL",
  super: "SUPERTREND",
  adx: "ADX",
  vwap: "VWAP",
};

const STATE_NAMES = { up: "WZROSTOWY", down: "SPADKOWY", neutral: "NEUTRALNY" };

function indicatorDetails(key, indicator) {
  const details = indicator?.details || {};
  if (key === "taker") return `Buy ${valueText(details.buy_pct)}% · Sell ${valueText(details.sell_pct)}%`;
  if (key === "macd") return `Linia MACD: ${valueText(details.signal)} · bullish: ${valueText(details.bullish)}`;
  if (key === "bolli") return `Szerokość: ${valueText(details.width)} · odchylenie: ${valueText(details.stddev)}`;
  if (key === "stoch") return `%D: ${valueText(details.d)}`;
  if (key === "adx") return `D+: ${valueText(details.dmp)} · D−: ${valueText(details.dmn)}`;
  if (key === "super") return `Ostatni flip: ${valueText(details.flip_recent)}`;
  return `Wartość: ${valueText(indicator?.value)}`;
}

function renderIndicators(indicators) {
  const cards = Object.entries(INDICATOR_NAMES).map(([key, label]) => {
    const indicator = indicators?.[key] || {};
    const stateName = String(indicator.state || "neutral").toLowerCase();
    const card = document.createElement("div");
    card.className = `indicator ${stateName}`;
    const name = document.createElement("span");
    name.textContent = label;
    const direction = document.createElement("b");
    direction.textContent = STATE_NAMES[stateName] || stateName.toUpperCase();
    const details = document.createElement("small");
    details.textContent = indicatorDetails(key, indicator);
    card.append(name, direction, details);
    return card;
  });
  $("#indicatorGrid").replaceChildren(...cards);
}

function safeEvidenceLink(label, value) {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.hostname !== "api.tradingzones.app") return null;
    const link = document.createElement("a");
    link.href = url.href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = label;
    return link;
  } catch {
    return null;
  }
}

function renderPaidReport(pkg, product) {
  $("#paidReport").classList.remove("hidden");
  $("#paidProduct").textContent = product;
  $("#paidDelivery").textContent = pkg.delivery_id ? `Dostawa: ${pkg.delivery_id}` : "";
  renderDetails($("#paidLevels"), [
    ["Kierunek", `${pkg.symbol} · ${pkg.direction}`],
    ["Entry Reference", price(pkg.entry_reference, pkg.symbol)],
    ["SL LQ", price(pkg.sl_lq, pkg.symbol)],
    ["TP LQ", price(pkg.tp_lq, pkg.symbol)],
  ]);
  renderDetails($("#setupDetails"), [
    ["Decyzja", `${pkg.action} · ${pkg.direction}`],
    ["Siła setupu", pkg.setup_strength_score == null ? "—" : `${pkg.setup_strength_score.toFixed(2)}/100`],
    ["Kwalifikacja ryzyka", pkg.risk_reward_status],
    ["Kod decyzji", pkg.reason_code],
    ["Kontekst", pkg.context?.badge],
    ["Pozycja w kanale", pkg.context?.position_pct == null ? "—" : `${Number(pkg.context.position_pct).toFixed(2)}%`],
    ["Opis", pkg.context?.message || pkg.reason],
    ["Ważna do", dateTime(pkg.valid_until)],
  ]);
  renderIndicators(pkg.indicators);

  const evidence = pkg.performance_evidence || {};
  const symbolStats = evidence.per_symbol_window_stats || {};
  const evidenceRows = [
    ["Skuteczność TZ‑SELECT", evidence.current_win_rate_pct == null ? "—" : `${evidence.current_win_rate_pct}%`],
    ["Zamknięte wybory", evidence.sample_size],
    ["Wygrane / przegrane", `${valueText(evidence.wins)} / ${valueText(evidence.losses)}`],
    ["Ostatnie 100", evidence.history_window_win_rate_pct == null ? "—" : `${evidence.history_window_win_rate_pct}%`],
  ];
  for (const symbol of ["BTC", "ETH", "XRP", "ONDO"]) {
    const stats = symbolStats[symbol];
    if (stats) evidenceRows.push([`${symbol} · okno`, `${stats.win_rate_pct}% (${stats.wins}/${stats.records})`]);
  }
  renderDetails($("#evidenceDetails"), evidenceRows);
  const links = [
    safeEvidenceLink("Aktualne podsumowanie", evidence.url),
    safeEvidenceLink("Historia wyników", evidence.history_url),
    safeEvidenceLink("Wykonania OKX", pkg.live_execution_evidence?.url),
  ].filter(Boolean);
  $("#evidenceLinks").replaceChildren(...links);

  const license = pkg.usage_license || {};
  renderDetails($("#technicalDetails"), [
    ["Produkt", product],
    ["Symbol dostarczony", pkg.symbol],
    ["Świeca zamknięta", dateTime(pkg.candle_closed_at)],
    ["Świeca źródłowa", dateTime(pkg.source_analysis_candle_time)],
    ["Wygenerowano", dateTime(pkg.generated_at)],
    ["ID analizy", pkg.signal_id],
    ["Rewizja", pkg.revision],
    ["Package ID", pkg.package_id],
    ["Selection ID", pkg.tz_select?.selection_id || "Nie dotyczy"],
    ["Licencja", license.license_id],
    ["Dozwolone użycie", Array.isArray(license.permitted_use) ? license.permitted_use.join(" · ") : "—"],
    ["Atrybucja", pkg.attribution],
  ]);
  $("#paidReport").scrollIntoView({ behavior: "smooth", block: "start" });
}

function assertOfficialConfig(config) {
  for (const [key, expected] of Object.entries(OFFICIAL_LINKS)) {
    if (config.official_links?.[key] !== expected) throw new Error(`Zmieniony oficjalny link: ${key}.`);
  }
  const payment = config.payment || {};
  if (payment.network !== BASE_NETWORK || payment.asset?.toLowerCase() !== BASE_USDC.toLowerCase()
      || payment.amount_atomic !== PAYMENT_AMOUNT || payment.pay_to?.toLowerCase() !== PAY_TO.toLowerCase()) {
    throw new Error("Konfiguracja płatności nie zgadza się z polityką bezpieczeństwa aplikacji.");
  }
}

async function openOfficialLink(key) {
  const expected = OFFICIAL_LINKS[key];
  if (!expected || state.config?.official_links?.[key] !== expected) {
    setStatus("error", "Link został zablokowany, ponieważ nie zgadza się z oficjalną listą.");
    return;
  }
  try {
    const response = await apiPost("/api/open-chrome", { target: key });
    setStatus("ok", response.fallback ? "Otwieram oficjalną stronę pobierania Chrome." : "Oficjalny link został otwarty w Google Chrome.");
  } catch (error) {
    setStatus("error", error.message);
  }
}

async function chooseInjectedProvider() {
  const announced = new Map();
  const listener = (event) => announced.set(event.detail.info.uuid, event.detail);
  window.addEventListener("eip6963:announceProvider", listener);
  window.dispatchEvent(new Event("eip6963:requestProvider"));
  await new Promise((resolve) => setTimeout(resolve, 180));
  window.removeEventListener("eip6963:announceProvider", listener);
  const options = [...announced.values()];
  const coinbase = options.find((entry) => /coinbase|base/i.test(`${entry.info.name} ${entry.info.rdns}`));
  if (coinbase) return { provider: coinbase.provider, name: coinbase.info.name };
  if (options[0]) return { provider: options[0].provider, name: options[0].info.name };
  if (window.ethereum) return { provider: window.ethereum, name: window.ethereum.isCoinbaseWallet ? "Coinbase Wallet" : "Portfel EVM" };
  return null;
}

async function ensureBase(provider) {
  const chainId = await provider.request({ method: "eth_chainId" });
  if (String(chainId).toLowerCase() === BASE_CHAIN_ID) return;
  await provider.request({ method: "wallet_switchEthereumChain", params: [{ chainId: BASE_CHAIN_ID }] });
  const confirmed = await provider.request({ method: "eth_chainId" });
  if (String(confirmed).toLowerCase() !== BASE_CHAIN_ID) throw new Error("Portfel nie przełączył się na Base Mainnet.");
}

async function refreshWallet() {
  if (!state.provider || !state.account) return;
  const publicClient = createPublicClient({ chain: base, transport: custom(state.provider) });
  const balance = await publicClient.readContract({
    address: BASE_USDC,
    abi: USDC_ABI,
    functionName: "balanceOf",
    args: [state.account],
  });
  $("#walletName").textContent = state.walletName;
  $("#walletAddress").textContent = shortAddress(state.account);
  $("#walletNetwork").textContent = "Base Mainnet";
  $("#walletBalance").textContent = `${Number(formatUnits(balance, 6)).toLocaleString("pl-PL", { maximumFractionDigits: 6 })} USDC`;
  $("#walletStatus").className = "wallet-status connected";
  $("#baseStep").classList.add("complete");
  setProductButtons(true);
}

async function connectWallet() {
  if (!isGoogleChrome()) {
    setStatus("error", "Moduł Base wymaga Google Chrome. Otwórz lokalny panel w Chrome.");
    return;
  }
  const selected = await chooseInjectedProvider();
  if (!selected) {
    setStatus("error", "Nie wykryto rozszerzenia portfela. Zainstaluj oficjalne rozszerzenie Coinbase Wallet / Base.");
    return;
  }
  setStatus("loading", "Łączę portfel i sprawdzam sieć Base…");
  const accounts = await selected.provider.request({ method: "eth_requestAccounts" });
  if (!accounts?.[0]) throw new Error("Portfel nie udostępnił adresu.");
  await ensureBase(selected.provider);
  state.provider = selected.provider;
  state.account = accounts[0];
  state.walletName = selected.name;

  const walletClient = createWalletClient({ account: state.account, chain: base, transport: custom(state.provider) });
  const publicClient = createPublicClient({ chain: base, transport: custom(state.provider) });
  const signer = {
    address: state.account,
    signTypedData: (message) => walletClient.signTypedData({ ...message, account: state.account }),
    readContract: (args) => publicClient.readContract(args),
  };
  const paymentClient = x402Client.fromConfig({
    schemes: [{ network: BASE_NETWORK, client: new ExactEvmScheme(signer) }],
    spendControls: { maxAmountPerPayment: "$0.03" },
    policies: [(_version, requirements) => requirements.filter((req) => (
      req.scheme === "exact"
      && req.network === BASE_NETWORK
      && String(req.asset).toLowerCase() === BASE_USDC.toLowerCase()
      && String(req.amount) === PAYMENT_AMOUNT
      && String(req.payTo).toLowerCase() === PAY_TO.toLowerCase()
    ))],
  });
  state.paidFetch = wrapFetchWithPayment(fetch, paymentClient);
  await refreshWallet();
  $("#connectWallet").textContent = "Portfel połączony";
  setStatus("ok", "Portfel połączony. Wybierz jeden z pięciu płatnych pakietów.");

  state.provider.on?.("accountsChanged", () => window.location.reload());
  state.provider.on?.("chainChanged", () => window.location.reload());
}

function confirmPayment(product) {
  const dialog = $("#paymentDialog");
  $("#dialogProduct").textContent = `${product} 4H`;
  dialog.returnValue = "cancel";
  dialog.showModal();
  return new Promise((resolve) => {
    dialog.addEventListener("close", () => resolve(dialog.returnValue === "confirm"), { once: true });
  });
}

async function purchase(product, button) {
  if (!PRODUCT_IDS.has(product) || !state.paidFetch || !state.config) return;
  if (!await confirmPayment(product)) return;
  button.disabled = true;
  setStatus("loading", `Portfel przygotowuje płatność za pakiet ${product}. Sprawdź wszystkie dane przed podpisem…`);
  try {
    const response = await state.paidFetch(`/api/x402/${encodeURIComponent(product)}`, {
      method: "GET",
      cache: "no-store",
      headers: { "X-TZ-CSRF": state.config.csrf_token },
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
    renderCore(data.package, true, product);
    renderPaidReport(data.package, product);
    setStatus("ok", `Płatność zakończona. Pełna analiza ${product} została dostarczona i zweryfikowana.`);
    await refreshWallet();
  } catch (error) {
    setStatus("error", `Zakup nie został zakończony: ${error.message}`);
  } finally {
    button.disabled = false;
  }
}

async function openInChrome() {
  try {
    const response = await fetch("/api/open-chrome", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-TZ-CSRF": state.config.csrf_token },
      body: JSON.stringify({ target: "local" }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Nie udało się uruchomić Chrome.");
    setStatus("ok", "TradingZones‑BOT został otwarty w Google Chrome.");
  } catch (error) {
    setStatus("error", `${error.message} Możesz pobrać Chrome z oficjalnego linku poniżej.`);
  }
}

async function apiPost(path, payload = {}) {
  if (!state.config) throw new Error("Brak aktywnej sesji lokalnej.");
  const response = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-TZ-CSRF": state.config.csrf_token },
    body: JSON.stringify(payload),
  });
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error(data.error || `Błąd HTTP ${response.status}`);
  return data;
}

async function restoreSessionPackages() {
  const response = await fetch("/api/session/packages", { cache: "no-store" });
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error(data.error || "Nie udało się odtworzyć pakietów sesji.");
  for (const record of data.packages || []) setOkxPackage(record.package, record.product, record.source);
}

function setOkxStatus(kind, text) {
  const node = $("#okxStatus");
  node.className = `status ${kind}`;
  node.textContent = text;
}

function packageIsTradable(pkg) {
  return pkg.action === "TRADE" && pkg.tradable === true && new Date(pkg.valid_until).getTime() > Date.now();
}

function renderPurchasedPackages() {
  const grid = $("#purchasedPackageGrid");
  if (!state.sessionPackages.size) {
    const empty = document.createElement("div");
    empty.className = "purchased-empty";
    empty.textContent = "Pobierz darmowy TZ‑SELECT lub kup analizę w zakładce Base.";
    grid.replaceChildren(empty);
    return;
  }
  const cards = [];
  for (const [deliveryId, record] of state.sessionPackages) {
    const pkg = record.package;
    const valid = packageIsTradable(pkg);
    const card = document.createElement("button");
    card.type = "button";
    card.className = `purchased-card${valid ? "" : " blocked"}${state.selectedPackageId === deliveryId ? " selected" : ""}`;
    card.dataset.deliveryId = deliveryId;
    const label = document.createElement("span");
    label.textContent = `${record.product || pkg.symbol} · ${record.source === "free" ? "DARMOWY" : "OPŁACONA"}`;
    const name = document.createElement("b");
    name.className = "purchased-name";
    name.textContent = pkg.symbol;
    const trend = document.createElement("div");
    trend.className = "purchased-trend";
    const trendLabel = document.createElement("span");
    trendLabel.textContent = "TREND";
    const trendValue = document.createElement("strong");
    const direction = String(pkg.direction || "—").toUpperCase();
    trendValue.className = direction === "LONG" ? "long" : (direction === "SHORT" ? "short" : "");
    trendValue.textContent = `${direction} ${direction === "LONG" ? "↑" : (direction === "SHORT" ? "↓" : "")}`.trim();
    trend.append(trendLabel, trendValue);
    const levels = document.createElement("div");
    levels.className = "purchased-levels";
    for (const [levelLabel, levelValue, levelClass] of [
      ["ENTRY", pkg.entry_reference, "entry"],
      ["SL LQ", pkg.sl_lq, "sl"],
      ["TP LQ", pkg.tp_lq, "tp"],
    ]) {
      const level = document.createElement("div");
      level.className = levelClass;
      const caption = document.createElement("span");
      caption.textContent = levelLabel;
      const value = document.createElement("b");
      value.textContent = price(levelValue, pkg.symbol);
      level.append(caption, value);
      levels.append(level);
    }
    const expiry = document.createElement("small");
    expiry.textContent = `Ważna do: ${dateTime(pkg.valid_until)}`;
    const status = document.createElement("em");
    status.textContent = valid ? (state.selectedPackageId === deliveryId ? "WYBRANA DO ZLECENIA" : "WYBIERZ DO ZLECENIA") : `${pkg.action} · NIEDOSTĘPNA DO ZLECENIA`;
    card.append(label, name, trend, levels, expiry, status);
    card.addEventListener("click", () => selectPaidPackage(deliveryId));
    cards.push(card);
  }
  grid.replaceChildren(...cards);
}

function selectPaidPackage(deliveryId) {
  const record = state.sessionPackages.get(deliveryId);
  if (!record) return;
  state.selectedPackageId = deliveryId;
  const valid = packageIsTradable(record.package);
  state.selectedPackage = valid ? record.package : null;
  renderPurchasedPackages();
  if (valid) {
    const message = state.okxAccount
      ? (state.okxAffiliate?.verified
        ? `Wybrano ${record.package.symbol} ${record.package.direction}. Pakiet, OKX i partnerstwo są gotowe do zlecenia.`
        : `Wybrano ${record.package.symbol} ${record.package.direction}. Automatyczne zlecenie wymaga potwierdzonego konta partnerskiego.`)
      : `Wybrano ${record.package.symbol} ${record.package.direction}. Połącz OKX, jeśli chcesz wysłać pozycję.`;
    setOkxStatus(state.okxAccount && !state.okxAffiliate?.verified ? "error" : "ok", message);
  } else {
    setOkxStatus("error", "Wybrany pakiet ma status NO_TRADE albo wygasł — zlecenie jest zablokowane.");
  }
  updateOrderControls();
}

function setOkxPackage(pkg, product, source = "paid") {
  const deliveryId = pkg.delivery_id;
  state.sessionPackages.set(deliveryId, { package: pkg, product: product || pkg.symbol, source });
  const previousTimer = state.packageExpiryTimers.get(deliveryId);
  if (previousTimer) clearTimeout(previousTimer);
  if (packageIsTradable(pkg)) {
    const delay = Math.max(0, new Date(pkg.valid_until).getTime() - Date.now());
    const timer = setTimeout(() => {
      state.packageExpiryTimers.delete(deliveryId);
      if (state.selectedPackageId === deliveryId) {
        state.selectedPackage = null;
        setOkxStatus("error", "Wybrana analiza wygasła. Wybierz inny aktualny pakiet lub pobierz nowy.");
      }
      renderPurchasedPackages();
      updateOrderControls();
    }, Math.min(delay + 250, 2_147_000_000));
    state.packageExpiryTimers.set(deliveryId, timer);
  }
  selectPaidPackage(deliveryId);
}

function okxCredentials() {
  return {
    api_key: $("#okxApiKey").value.trim(),
    secret_key: $("#okxSecret").value.trim(),
    passphrase: $("#okxPassphrase").value,
    demo: false,
    region: $("#okxRegion").value,
  };
}

function renderOkxAccount(account, loaded = false) {
  state.okxAccount = account;
  const available = Number(account.available_usdc || 0);
  $("#okxConnection").textContent = loaded ? "Połączony · dane wczytane" : "Połączony";
  $("#okxAvailable").textContent = `${available.toLocaleString("pl-PL", { maximumFractionDigits: 2 })} USDC`;
  $("#okxPositionMode").textContent = account.position_mode || "—";
  $("#okxEnvironment").textContent = `${account.demo ? "DEMO" : "LIVE"} · ${String(account.region).toUpperCase()}`;
  $("#okxAccount").className = "wallet-status connected";
  $("#okxMargin").max = String(available);
  $("#okxModeBadge").textContent = account.demo ? "DEMO" : "LIVE";
  $("#okxModeBadge").className = `mode-badge ${account.demo ? "demo" : "live"}`;
  $("#okxStep").classList.add("complete");
  if (loaded) {
    state.okxCredentialsLoaded = true;
    for (const selector of ["#okxApiKey", "#okxSecret", "#okxPassphrase"]) {
      const input = $(selector);
      input.value = "";
      input.placeholder = "••••••••••••";
      input.dataset.saved = "true";
    }
  }
  updateOrderControls();
}

function renderOkxAffiliate(affiliate) {
  state.okxAffiliate = affiliate || { verified: false, operational: false, source: "not_checked" };
  const verified = state.okxAffiliate.verified === true;
  const operational = state.okxAffiliate.operational === true;
  const card = $("#okxAffiliateStatus");
  card.className = `affiliate-status ${verified ? "verified" : "blocked"}`;
  $("#okxAffiliateTitle").textContent = verified
    ? "Konto partnerskie zweryfikowane"
    : (operational ? "Konto nie jest przypisane" : "Nie udało się potwierdzić konta");
  $("#okxAffiliateMessage").textContent = verified
    ? "Automatyczne wysyłanie zleceń jednym kliknięciem jest odblokowane."
    : (state.okxAffiliate.message || "Sprawdź ponownie lub utwórz konto przez oficjalny link Trading Zones.");
  $("#okxAffiliateCheck").disabled = !state.okxAccount;
  updateOrderControls();
}

function updateNotional() {
  const margin = Number($("#okxMargin").value || 0);
  const leverage = Number($("#okxLeverage").value || 1);
  $("#okxNotional").textContent = margin > 0 ? `${(margin * leverage).toLocaleString("pl-PL", { maximumFractionDigits: 2 })} USDC` : "—";
}

function updateOrderControls() {
  const enabled = Boolean(state.selectedPackage && state.okxAccount && state.okxAffiliate?.verified);
  $("#okxMargin").disabled = !enabled;
  $("#okxLeverage").disabled = !enabled;
  $("#okxApproval").disabled = !enabled;
  $("#okxPreview").disabled = !enabled || !$("#okxApproval").checked;
  $("#orderBuilder").className = `order-builder ${enabled ? "ready-order" : "locked-order"}`;
  updateNotional();
}

async function connectOkx(payload = null, loaded = false) {
  state.okxAffiliate = null;
  updateOrderControls();
  setOkxStatus("loading", "Łączę konto OKX, pobieram saldo i sprawdzam przypisanie partnerskie…");
  const entered = payload || okxCredentials();
  const hasAnyEnteredCredential = Boolean(entered.api_key || entered.secret_key || entered.passphrase);
  const useSaved = loaded || (!hasAnyEnteredCredential && state.okxCredentialsLoaded);
  const data = useSaved ? await apiPost("/api/okx/load") : await apiPost("/api/okx/connect", entered);
  renderOkxAccount(data.account, Boolean(data.loaded));
  renderOkxAffiliate(data.affiliate);
  if (data.affiliate?.verified) {
    setOkxStatus("ok", state.selectedPackage
      ? `OKX połączony i zweryfikowany. Dostępne saldo: ${data.account.available_usdc} USDC. Pakiet TRADE jest gotowy.`
      : `OKX połączony i zweryfikowany. Dostępne saldo: ${data.account.available_usdc} USDC.`);
  } else {
    setOkxStatus("error", "OKX połączony, ale automatyczne zlecenia pozostają zablokowane. Zakup analiz i handel ręczny nadal są dostępne.");
  }
}

async function verifyOkxAffiliate() {
  if (!state.okxAccount) throw new Error("Najpierw połącz konto OKX.");
  setOkxStatus("loading", "Sprawdzam ponownie konto główne w programie Trading Zones × OKX…");
  const data = await apiPost("/api/okx/affiliate/verify");
  renderOkxAffiliate(data.affiliate);
  setOkxStatus(data.affiliate.verified ? "ok" : "error", data.affiliate.verified
    ? "Konto partnerskie zweryfikowane. Automatyczne zlecenia są odblokowane."
    : "Konto nie zostało potwierdzone. Analizy pozostają dostępne, a zlecenie możesz wykonać ręcznie.");
}

async function saveOkxCredentials() {
  await apiPost("/api/okx/save", okxCredentials());
  setOkxStatus("ok", "Dane API zaszyfrowano przez Windows DPAPI i przypisano do tego konta Windows.");
}

async function deleteSavedOkxCredentials() {
  const data = await apiPost("/api/okx/delete-saved");
  state.okxCredentialsLoaded = false;
  for (const selector of ["#okxApiKey", "#okxSecret", "#okxPassphrase"]) {
    const input = $(selector);
    input.value = "";
    input.placeholder = "";
    delete input.dataset.saved;
  }
  setOkxStatus("ok", data.deleted ? "Zaszyfrowany zapis danych API został usunięty." : "Nie było zapisanego pliku danych API.");
}

function confirmOrder(preview, demo) {
  const rows = [
    ["Tryb", demo ? "DEMO" : "LIVE"], ["Instrument", preview.inst_id], ["Kierunek", preview.direction],
    ["Wejście", "MARKET"], ["Margin", `${preview.margin_usdc} USDC`], ["Dźwignia", `${preview.leverage}x`],
    ["Wartość pozycji", `${Number(preview.actual_notional_usdc).toLocaleString("pl-PL", { maximumFractionDigits: 2 })} USDC`], ["Kontrakty", preview.contracts],
    ["Limit dźwigni OKX", `${preview.max_leverage}x`],
    ["Cena mark", price(preview.mark_price, preview.inst_id)],
    ["TP LQ LIMIT", price(preview.take_profit, preview.inst_id)],
    ["SL LQ LIMIT", price(preview.stop_loss, preview.inst_id)],
  ];
  const grid = $("#orderConfirmGrid");
  grid.replaceChildren();
  for (const [label, value] of rows) {
    const span = document.createElement("span"); span.textContent = label;
    const b = document.createElement("b"); b.textContent = value;
    grid.append(span, b);
  }
  $("#orderDialogMode").textContent = `OKX ${demo ? "DEMO" : "LIVE"}`;
  $("#liveWarning").classList.toggle("hidden", demo);
  const dialog = $("#orderDialog");
  dialog.returnValue = "cancel";
  dialog.showModal();
  return new Promise((resolve) => dialog.addEventListener("close", () => resolve(dialog.returnValue === "confirm"), { once: true }));
}

async function prepareOkxOrder() {
  if (!state.okxAffiliate?.verified) throw new Error("Najpierw zweryfikuj konto partnerskie OKX.");
  if (!$("#okxApproval").checked) throw new Error("Zaznacz „Tak, potwierdzam”, aby przygotować zlecenie.");
  const margin = Number($("#okxMargin").value);
  const available = Number(state.okxAccount?.available_usdc || 0);
  if (!(margin > 0) || margin > available) throw new Error(`Margin musi być większy od 0 i nie może przekraczać ${available} USDC.`);
  setOkxStatus("loading", "Ponownie sprawdzam saldo, cenę, kontrakt i istniejące pozycje…");
  const data = await apiPost("/api/okx/preview", {
    delivery_id: state.selectedPackage.delivery_id,
    margin: String(margin),
    leverage: Number($("#okxLeverage").value),
  });
  state.confirmationToken = data.confirmation_token;
  state.orderPreview = data.preview;
  $("#okxLeverage").max = String(data.preview.max_leverage);
  $("#okxLeverageLimit").textContent = `Limit instrumentu: ${data.preview.max_leverage}x · limit bota: 10x`;
  if (!await confirmOrder(data.preview, state.okxAccount.demo)) {
    setOkxStatus("idle", "Zlecenie anulowane przed wysłaniem do OKX.");
    return;
  }
  setOkxStatus("loading", "Sprawdzam saldo i rynek po raz drugi, a następnie wysyłam jedno zlecenie MARKET z TP/SL…");
  const placed = await apiPost("/api/okx/order", { confirmation_token: state.confirmationToken });
  $("#positionTitle").textContent = `${placed.position.symbol} ${placed.position.direction} · ${Number(placed.position.actual_notional_usdc).toLocaleString("pl-PL", { maximumFractionDigits: 2 })} USDC`;
  $("#positionOrderId").textContent = placed.order.order_id;
  $("#positionCard").classList.remove("hidden");
  $("#okxApproval").checked = false;
  setOkxStatus("ok", "OKX przyjął wejście MARKET wraz z TP LQ LIMIT i SL LQ LIMIT. Otwórz teraz OKX i samodzielnie sprawdź całą pozycję oraz ochronę.");
  renderOkxAccount(placed.account);
}

async function refreshPosition() {
  const data = await apiPost("/api/okx/status");
  setOkxStatus("ok", data.position ? `Pozycja aktywna: ${data.position.pos} kontraktów.` : "OKX nie zwraca aktywnej pozycji dla tego zlecenia.");
}

function confirmClose() {
  const dialog = $("#closeDialog"); dialog.returnValue = "cancel"; dialog.showModal();
  return new Promise((resolve) => dialog.addEventListener("close", () => resolve(dialog.returnValue === "confirm"), { once: true }));
}

async function closePosition() {
  if (!await confirmClose()) return;
  setOkxStatus("loading", "Zamykam całą pozycję z rynku i anuluję ochronę…");
  await apiPost("/api/okx/close", { confirm: "ZAMKNIJ" });
  $("#positionCard").classList.add("hidden");
  setOkxStatus("ok", "OKX potwierdził żądanie zamknięcia pozycji.");
}

async function fetchFree() {
  const button = $("#fetchButton");
  button.disabled = true;
  $("#result").classList.add("hidden");
  setStatus("loading", "Pobieram i waliduję bieżący darmowy pakiet TZ‑SELECT…");
  try {
    const response = await fetch("/api/tz-select/free", { cache: "no-store" });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
    renderCore(data.package, false);
    $("#buyFullTzSelect").classList.remove("hidden");
    $("#freeStep").classList.add("complete");
    setStatus("ok", "Darmowy pakiet został pobrany i przeszedł walidację bezpieczeństwa.");
  } catch (error) {
    setStatus("error", `Nie można użyć analizy: ${error.message}`);
  } finally {
    button.disabled = false;
  }
}

async function buyFullTzSelect() {
  switchTab("base");
  const button = $('.product-button[data-product="TZ-SELECT"]');
  button.scrollIntoView({ behavior: "smooth", block: "center" });
  if (!state.paidFetch) {
    $("#connectWallet").focus();
    return;
  }
  await purchase("TZ-SELECT", button);
}

async function initialize() {
  try {
    const response = await fetch("/api/config", { cache: "no-store" });
    const config = await response.json();
    if (!response.ok || !config.ok) throw new Error("Nie udało się pobrać konfiguracji lokalnej.");
    assertOfficialConfig(config);
    state.config = config;
    $(".paid-products").classList.add("panel", "standalone-paid-products");
    await restoreSessionPackages();
  } catch (error) {
    setStatus("error", `Aplikacja została zablokowana: ${error.message}`);
    $("#connectWallet").disabled = true;
    return;
  }
  const chrome = isGoogleChrome();
  $("#browserWarning").classList.toggle("hidden", chrome);
  $("#connectWallet").disabled = !chrome;
  if (!chrome) setStatus("error", "Darmowa analiza działa, ale moduł Base wymaga uruchomienia panelu w Google Chrome.");
}

$("#fetchButton").addEventListener("click", fetchFree);
$("#buyFullTzSelect").addEventListener("click", () => buyFullTzSelect().catch((error) => setStatus("error", error.message)));
$$('[data-tab]').forEach((tab) => tab.addEventListener("click", () => switchTab(tab.dataset.tab)));
$("#connectWallet").addEventListener("click", () => connectWallet().catch((error) => setStatus("error", `Nie połączono portfela: ${error.message}`)));
$("#openChromeButton").addEventListener("click", openInChrome);
$$('[data-official-link]').forEach((button) => button.addEventListener("click", () => openOfficialLink(button.dataset.officialLink)));
$$('.product-button').forEach((button) => button.addEventListener("click", () => purchase(button.dataset.product, button)));
$("#okxMargin").addEventListener("input", updateNotional);
$("#okxLeverage").addEventListener("change", updateNotional);
$("#okxApproval").addEventListener("change", updateOrderControls);
$("#okxConnect").addEventListener("click", () => connectOkx().catch((error) => setOkxStatus("error", error.message)));
$("#okxSave").addEventListener("click", () => saveOkxCredentials().catch((error) => setOkxStatus("error", error.message)));
$("#okxLoad").addEventListener("click", () => connectOkx({}, true).catch((error) => setOkxStatus("error", error.message)));
$("#okxDeleteSaved").addEventListener("click", () => deleteSavedOkxCredentials().catch((error) => setOkxStatus("error", error.message)));
$("#okxAffiliateCheck").addEventListener("click", () => verifyOkxAffiliate().catch((error) => setOkxStatus("error", error.message)));
$("#okxPreview").addEventListener("click", () => prepareOkxOrder().catch((error) => setOkxStatus("error", error.message)));
$("#refreshPosition").addEventListener("click", () => refreshPosition().catch((error) => setOkxStatus("error", error.message)));
$("#closePosition").addEventListener("click", () => closePosition().catch((error) => setOkxStatus("error", error.message)));

initialize();
