import io
import json
import unittest
from unittest.mock import patch

import app


class FakeResponse:
    def __init__(self, payload):
        self.payload = payload

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self):
        return json.dumps(self.payload).encode("utf-8")


class AffiliateVerificationTests(unittest.TestCase):
    def test_only_main_uid_is_sent_and_verified_identity_is_pinned(self):
        captured = {}

        def fake_urlopen(request, **_kwargs):
            captured["url"] = request.full_url
            captured["body"] = json.loads(request.data.decode("utf-8"))
            return FakeResponse({
                "verified": True,
                "source": "admin_allowlist",
                "affiliate_code": app.OKX_AFFILIATE_CODE,
                "join_url": app.OKX_AFFILIATE_JOIN_URL,
            })

        with patch.object(app, "urlopen", fake_urlopen):
            result = app.verify_okx_affiliate("855059452339618939")

        self.assertTrue(result["verified"])
        self.assertEqual(captured["url"], app.OKX_AFFILIATE_VERIFY_URL)
        self.assertEqual(captured["body"], {"main_uid": "855059452339618939"})

    def test_wrong_partner_identity_is_rejected(self):
        response = FakeResponse({
            "verified": True,
            "source": "okx_affiliate_api",
            "affiliate_code": "WRONG",
            "join_url": app.OKX_AFFILIATE_JOIN_URL,
        })
        with patch.object(app, "urlopen", return_value=response):
            result = app.verify_okx_affiliate("855059452339618939")
        self.assertFalse(result["verified"])
        self.assertEqual(result["source"], "identity_mismatch")

    def test_invalid_uid_never_calls_remote_service(self):
        with patch.object(app, "urlopen") as mocked:
            result = app.verify_okx_affiliate("not-a-uid")
        mocked.assert_not_called()
        self.assertFalse(result["verified"])
        self.assertEqual(result["source"], "missing_main_uid")


if __name__ == "__main__":
    unittest.main()
