import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from okx_client import OkxClient, OkxCredentials, OkxError
from app import BotHandler


def package(direction="LONG"):
    return {
        "delivery_id": "tzdlv_test",
        "symbol": "XRP",
        "action": "TRADE",
        "tradable": True,
        "direction": direction,
        "sl_lq": 0.9 if direction == "LONG" else 1.1,
        "tp_lq": 1.1 if direction == "LONG" else 0.9,
        "valid_until": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
    }


class PreviewClient(OkxClient):
    def __init__(self, available="100", position_mode="net_mode"):
        super().__init__(OkxCredentials("key", "secret", "pass", True, "eea"))
        self.available = available
        self.position_mode = position_mode

    def account_summary(self):
        return {"available_usdc": self.available, "equity_usdc": self.available, "position_mode": self.position_mode,
                "account_level": "2", "demo": True, "region": "eea"}

    def instrument(self, symbol):
        return {"instId": f"{symbol}-USD_UM_XPERP-310404", "state": "live", "ctType": "linear", "ctValCcy": symbol,
                "ctVal": "10", "ctMult": "1", "lotSz": "1", "minSz": "1", "lever": "100"}

    def positions(self, inst_id):
        return []

    def pending_orders(self, inst_id):
        return []

    def mark_price(self, inst_id):
        return Decimal("1")


class OrderClient(OkxClient):
    def __init__(self, mode="long_short_mode"):
        super().__init__(OkxCredentials("key", "secret", "pass", True, "eea"))
        self.mode = mode
        self.calls = []

    def _request(self, method, path, params=None, body=None, private=True):
        self.calls.append((method, path, params, body))
        if path.endswith("leverage-info"):
            sides = ["long", "short"] if self.mode == "long_short_mode" else [""]
            return [{"instId": "XRP-USD_UM_XPERP-310404", "posSide": side, "lever": "5"} for side in sides]
        if path.endswith("/order"):
            return [{"sCode": "0", "ordId": "123"}]
        return [{}]


class OkxTests(unittest.TestCase):
    def test_local_app_forces_live_mode(self):
        credentials = BotHandler._credentials({
            "api_key": "key", "secret_key": "secret", "passphrase": "pass", "demo": True, "region": "eea"
        })
        self.assertFalse(credentials.demo)

    def test_margin_is_rechecked_against_available_balance(self):
        client = PreviewClient(available="100")
        with self.assertRaisesRegex(OkxError, "przekracza"):
            client.preview(package(), Decimal("1000"), 5)

    def test_margin_times_leverage_becomes_position_value(self):
        preview = PreviewClient().preview(package(), Decimal("20"), 5)
        self.assertEqual(preview["requested_notional_usdc"], "100")
        self.assertEqual(preview["actual_notional_usdc"], "100")
        self.assertEqual(preview["contracts"], "10")

    def test_leverage_outside_fixed_list_is_blocked(self):
        for leverage in (7, 15, 20):
            with self.subTest(leverage=leverage), self.assertRaisesRegex(OkxError, "bezpiecznej listy"):
                PreviewClient().preview(package(), Decimal("20"), leverage)

    def test_played_out_analysis_has_clear_message(self):
        client = PreviewClient()
        client.mark_price = lambda _inst_id: Decimal("1.2")
        with self.assertRaisesRegex(OkxError, "analiza już się rozegrała"):
            client.preview(package(), Decimal("20"), 5)

    def test_leverage_readback_and_atomic_limit_protection(self):
        client = OrderClient()
        preview = {
            "inst_id": "XRP-USD_UM_XPERP-310404", "position_mode": "long_short_mode", "direction": "LONG", "side": "buy",
            "leverage": 5, "contracts": "10", "take_profit": "1.1", "stop_loss": "0.9",
        }
        result = client.place_order(preview)
        self.assertEqual(result["order_id"], "123")
        leverage_calls = [call for call in client.calls if call[1].endswith("set-leverage")]
        self.assertEqual({call[3]["posSide"] for call in leverage_calls}, {"long", "short"})
        order = next(call[3] for call in client.calls if call[1].endswith("/order"))
        self.assertEqual(order["ordType"], "market")
        self.assertEqual(order["tdMode"], "cross")
        self.assertEqual(order["attachAlgoOrds"][0]["tpOrdPx"], "1.1")
        self.assertEqual(order["attachAlgoOrds"][0]["slOrdPx"], "0.9")

    def test_wrong_leverage_readback_blocks_order(self):
        client = OrderClient()
        original = client._request

        def wrong(method, path, params=None, body=None, private=True):
            if path.endswith("leverage-info"):
                return [{"instId": "XRP-USD_UM_XPERP-310404", "posSide": side, "lever": "3"} for side in ("long", "short")]
            return original(method, path, params, body, private)

        client._request = wrong
        with self.assertRaisesRegex(OkxError, "nie potwierdził"):
            client.place_order({"inst_id": "XRP-USD_UM_XPERP-310404", "position_mode": "long_short_mode", "direction": "LONG",
                                "side": "buy", "leverage": 5, "contracts": "10", "take_profit": "1.1", "stop_loss": "0.9"})

    def test_account_summary_reads_usdc_available_equity(self):
        client = OkxClient(OkxCredentials("key", "secret", "pass", False, "eea"))

        def fake(method, path, params=None, body=None, private=True):
            if path.endswith("/config"):
                return [{"posMode": "net_mode", "acctLv": "2", "uid": "222", "mainUid": "111"}]
            self.assertEqual(params, {"ccy": "USDC"})
            return [{"details": [
                {"ccy": "USDT", "availEq": "999"},
                {"ccy": "USDC", "availEq": "25.75", "availBal": "24", "eq": "30"},
            ]}]

        client._request = fake
        summary = client.account_summary()
        self.assertEqual(summary["available_usdc"], "25.75")
        self.assertEqual(summary["equity_usdc"], "30")
        self.assertEqual(summary["uid"], "222")
        self.assertEqual(summary["main_uid"], "111")


if __name__ == "__main__":
    unittest.main()
