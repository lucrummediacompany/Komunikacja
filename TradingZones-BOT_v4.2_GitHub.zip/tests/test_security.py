"""Offline security regressions; dummy values, no exchange or wallet transactions."""
import json
import ssl
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request, build_opener

import app
from okx_client import OkxCredentials
from secure_http import NoRedirectHandler, safe_urlopen


class LocalSecurityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), app.BotHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)

    def request(self, path, headers=None, data=None, method=None):
        return build_opener().open(Request(self.base+path, headers=headers or {}, data=data, method=method), timeout=3)

    def test_foreign_host_is_blocked(self):
        with self.assertRaises(HTTPError) as caught:
            self.request('/api/config', {'Host': 'attacker.example'})
        self.assertEqual(caught.exception.code, 403)

    def test_other_local_port_is_blocked(self):
        with self.assertRaises(HTTPError) as caught:
            self.request('/api/config', {'Origin': 'http://localhost:1'})
        self.assertEqual(caught.exception.code, 403)

    def test_null_and_foreign_origins_blocked(self):
        for origin in ['null', 'https://attacker.example']:
            with self.assertRaises(HTTPError) as caught:
                self.request('/api/config', {'Origin': origin})
            self.assertEqual(caught.exception.code, 403)

    def test_post_requires_session_token(self):
        with self.assertRaises(HTTPError) as caught:
            self.request('/api/okx/load', {'Content-Type':'application/json'}, data=b'{}')
        self.assertEqual(caught.exception.code, 403)

    def test_same_origin_config_and_security_headers(self):
        with self.request('/api/config', {'Origin':self.base}) as response:
            payload=json.load(response)
            self.assertGreater(len(payload['csrf_token']),30)
            self.assertEqual(response.headers['X-Frame-Options'],'DENY')
            self.assertNotIn('api_key',payload)
        with self.request('/index.html') as response:
            self.assertIn("frame-ancestors 'none'",response.headers['Content-Security-Policy'])

    def test_head_also_blocks_foreign_host(self):
        with self.assertRaises(HTTPError) as caught:
            self.request('/index.html', {'Host':'attacker.example'}, method='HEAD')
        self.assertEqual(caught.exception.code,403)

    def test_credentials_not_in_repr(self):
        rendered=repr(OkxCredentials('dummy-key','dummy-secret','dummy-pass'))
        self.assertNotIn('dummy-',rendered)

    def test_transport_requires_https(self):
        with self.assertRaises(ValueError):
            safe_urlopen('http://attacker.example/',timeout=1,context=ssl.create_default_context())

    def test_redirect_never_delivers_custom_headers(self):
        received=[]
        class Redirector(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path=='/redirect':
                    self.send_response(302)
                    self.send_header('Location','/capture')
                    self.end_headers()
                else:
                    received.append(self.headers.get('OK-ACCESS-PASSPHRASE'))
                    self.send_response(200);self.end_headers()
            def log_message(self,*args):pass
        server=ThreadingHTTPServer(('127.0.0.1',0),Redirector)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            request=Request(f'http://127.0.0.1:{server.server_port}/redirect',headers={'OK-ACCESS-PASSPHRASE':'dummy-only'})
            with self.assertRaises(HTTPError) as caught:
                build_opener(NoRedirectHandler()).open(request,timeout=3)
            self.assertEqual(caught.exception.code,302)
            self.assertEqual(received,[])
        finally:
            server.shutdown();server.server_close();thread.join(timeout=3)


if __name__=='__main__':unittest.main()
