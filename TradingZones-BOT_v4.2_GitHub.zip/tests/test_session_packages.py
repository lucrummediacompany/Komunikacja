import json
import threading
import unittest
from datetime import datetime, timedelta, timezone
from http.server import ThreadingHTTPServer
from urllib.request import Request, urlopen

import app
from app import BotHandler


class FakeOkxClient:
    def preview(self, package, margin, leverage):
        return {
            "inst_id": "BTC-USD_UM_XPERP-310404",
            "symbol": package["symbol"],
            "direction": package["direction"],
            "contracts": "1",
            "stop_loss": str(package["sl_lq"]),
            "take_profit": str(package["tp_lq"]),
            "margin_usdc": str(margin),
            "leverage": leverage,
            "delivery_id": package["delivery_id"],
        }


class FreeSessionPackageTests(unittest.TestCase):
    def setUp(self):
        self.original_fetch = app.fetch_free_package
        self.original_verify = app.verify_okx_affiliate
        app.verify_okx_affiliate = lambda _main_uid: {
            "verified": True, "operational": True, "source": "test",
            "join_url": app.OKX_AFFILIATE_JOIN_URL, "affiliate_code": app.OKX_AFFILIATE_CODE,
        }
        valid_until = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat().replace("+00:00", "Z")
        app.fetch_free_package = lambda: {
            "delivery_id": "",
            "symbol": "BTC",
            "direction": "SHORT",
            "action": "TRADE",
            "tradable": True,
            "entry_reference": 100.0,
            "sl_lq": 101.0,
            "tp_lq": 99.0,
            "valid_until": valid_until,
            "setup_strength_score": 52.0,
            "context": {},
        }
        app.PAID_PACKAGES.clear()
        app.PAID_PACKAGE_PRODUCTS.clear()
        app.FREE_PACKAGES.clear()
        app.OKX_PREVIEWS.clear()
        app.OKX_SESSION.update({
            "client": FakeOkxClient(), "summary": {"main_uid": "855059452339618939"},
            "position": None, "affiliate": None,
        })
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), BotHandler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        app.fetch_free_package = self.original_fetch
        app.verify_okx_affiliate = self.original_verify
        app.FREE_PACKAGES.clear()
        app.OKX_PREVIEWS.clear()
        app.OKX_SESSION.update({"client": None, "summary": None, "position": None, "affiliate": None})

    def test_free_tz_select_is_listed_and_accepted_for_preview(self):
        free = json.load(urlopen(self.base + "/api/tz-select/free"))["package"]
        self.assertEqual(free["delivery_id"], "tzfree_current")

        records = json.load(urlopen(self.base + "/api/session/packages"))["packages"]
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["source"], "free")
        self.assertEqual(records[0]["product"], "TZ-SELECT")

        request = Request(
            self.base + "/api/okx/preview",
            data=json.dumps({"delivery_id": "tzfree_current", "margin": "5", "leverage": 5}).encode(),
            headers={"Content-Type": "application/json", "X-TZ-CSRF": app.CSRF_TOKEN},
            method="POST",
        )
        preview = json.load(urlopen(request))
        self.assertTrue(preview["ok"])
        self.assertEqual(preview["preview"]["delivery_id"], "tzfree_current")

    def test_preview_is_blocked_for_non_affiliate_without_blocking_package_access(self):
        app.verify_okx_affiliate = lambda _main_uid: {
            "verified": False, "operational": True, "source": "not_invitee",
            "message": "Konto nie jest przypisane.",
        }
        free = json.load(urlopen(self.base + "/api/tz-select/free"))["package"]
        self.assertEqual(free["delivery_id"], "tzfree_current")
        request = Request(
            self.base + "/api/okx/preview",
            data=json.dumps({"delivery_id": "tzfree_current", "margin": "5", "leverage": 5}).encode(),
            headers={"Content-Type": "application/json", "X-TZ-CSRF": app.CSRF_TOKEN},
            method="POST",
        )
        with self.assertRaises(Exception) as context:
            urlopen(request)
        self.assertEqual(context.exception.code, 400)


if __name__ == "__main__":
    unittest.main()
