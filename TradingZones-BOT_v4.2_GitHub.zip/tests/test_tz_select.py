import unittest
import base64
import json
from datetime import datetime, timezone

from app import (
    BASE_NETWORK,
    BASE_USDC,
    PAID_PRODUCTS,
    PAYMENT_AMOUNT_ATOMIC,
    PAY_TO,
    BotHandler,
)
from tz_select import TzSelectError, validate_package


NOW = datetime(2026, 11, 10, 9, 30, tzinfo=timezone.utc)


def sample():
    return {
        "schema_version": "1.4",
        "package_id": "pkg",
        "delivery_id": "delivery",
        "symbol": "BTC",
        "interval": "4h",
        "decision": "SHORT",
        "direction": "SHORT",
        "action": "TRADE",
        "tradable": True,
        "reason_code": "TRADE_ELIGIBLE",
        "setup_strength_score": 52.28,
        "valid_until": "2026-11-10T12:00:00Z",
        "entry": {"b2b_reference_price": 74848.6},
        "levels": {
            "stop_loss_liquidity_guard": 75895.71,
            "take_profit_liquidity_guard": 74517.42,
        },
        "tz_select": {
            "selection_id": "cycle:BTC",
            "selected_symbol": "BTC",
            "selection_valid_until": "2026-11-10T12:00:00Z",
        },
    }


class ValidationTests(unittest.TestCase):
    def test_valid_short(self):
        result = validate_package(sample(), now=NOW)
        self.assertTrue(result["tradable"])
        self.assertEqual(result["symbol"], "BTC")
        self.assertEqual(result["sl_lq"], 75895.71)

    def test_expired_is_blocked(self):
        data = sample()
        data["valid_until"] = "2026-11-10T09:00:00Z"
        with self.assertRaisesRegex(TzSelectError, "wygasła"):
            validate_package(data, now=NOW)

    def test_missing_liquidity_level_is_blocked(self):
        data = sample()
        data["levels"].pop("stop_loss_liquidity_guard")
        with self.assertRaisesRegex(TzSelectError, "SL LQ"):
            validate_package(data, now=NOW)

    def test_wrong_geometry_is_blocked(self):
        data = sample()
        data["levels"]["stop_loss_liquidity_guard"] = 74000
        with self.assertRaisesRegex(TzSelectError, "Geometria"):
            validate_package(data, now=NOW)

    def test_no_trade_is_valid_but_not_tradable(self):
        data = sample()
        data.update({"action": "NO_TRADE", "tradable": False, "decision": "NEUTRAL", "direction": "SHORT"})
        data["levels"] = {}
        data["entry"] = {}
        result = validate_package(data, now=NOW)
        self.assertFalse(result["tradable"])
        self.assertEqual(result["action"], "NO_TRADE")

    def test_standard_paid_product_does_not_require_selector(self):
        data = sample()
        data["tz_select"] = None
        result = validate_package(data, now=NOW, expected_product="BTC")
        self.assertEqual(result["product"], "BTC")
        self.assertEqual(result["tz_select"], {})

    def test_paid_product_symbol_mismatch_is_blocked(self):
        data = sample()
        data["tz_select"] = None
        with self.assertRaisesRegex(TzSelectError, "wybranym produktem"):
            validate_package(data, now=NOW, expected_product="ETH")

    def test_pinned_x402_requirement(self):
        requirement = {
            "x402Version": 2,
            "resource": {"url": PAID_PRODUCTS["BTC"]},
            "accepts": [{
                "scheme": "exact",
                "network": BASE_NETWORK,
                "asset": BASE_USDC,
                "amount": PAYMENT_AMOUNT_ATOMIC,
                "payTo": PAY_TO,
            }],
        }
        encoded = base64.urlsafe_b64encode(json.dumps(requirement).encode()).decode().rstrip("=")
        decoded = BotHandler._validate_payment_required(encoded, PAID_PRODUCTS["BTC"])
        self.assertEqual(decoded["x402Version"], 2)

        requirement["accepts"][0]["amount"] = "100000"
        tampered = base64.urlsafe_b64encode(json.dumps(requirement).encode()).decode().rstrip("=")
        with self.assertRaisesRegex(TzSelectError, "nie zgadza"):
            BotHandler._validate_payment_required(tampered, PAID_PRODUCTS["BTC"])


if __name__ == "__main__":
    unittest.main()
