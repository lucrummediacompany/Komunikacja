import assert from "node:assert/strict";
import { x402Client } from "@x402/core/client";
import { ExactEvmScheme } from "@x402/evm/exact/client";
import { wrapFetchWithPayment } from "@x402/fetch";

const network = "eip155:8453";
const asset = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913";
const payTo = "0x449352D4B7A7928dBE64eec73B2427B7b3C98e81";
const amount = "30000";
let signed = false;
let calls = 0;

const signer = {
  address: "0x1111111111111111111111111111111111111111",
  async signTypedData() {
    signed = true;
    return `0x${"11".repeat(65)}`;
  },
};

const client = x402Client.fromConfig({
  schemes: [{ network, client: new ExactEvmScheme(signer) }],
  spendControls: { maxAmountPerPayment: "$0.03" },
  policies: [(_version, requirements) => requirements.filter((req) => (
    req.scheme === "exact"
    && req.network === network
    && req.asset.toLowerCase() === asset.toLowerCase()
    && req.amount === amount
    && req.payTo.toLowerCase() === payTo.toLowerCase()
  ))],
});

const required = {
  x402Version: 2,
  error: "Payment required",
  resource: {
    url: "https://api.tradingzones.app/v1/signals/BTC/4h",
    description: "Test",
    mimeType: "application/json",
  },
  accepts: [{
    scheme: "exact",
    network,
    asset,
    amount,
    payTo,
    maxTimeoutSeconds: 300,
    extra: { name: "USD Coin", version: "2" },
  }],
  extensions: {},
};
const encoded = Buffer.from(JSON.stringify(required)).toString("base64url");

const mockFetch = async (input, init = {}) => {
  calls += 1;
  if (calls === 1) {
    return new Response("{}", { status: 402, headers: { "PAYMENT-REQUIRED": encoded } });
  }
  const headers = input instanceof Request ? input.headers : new Headers(init.headers);
  assert.ok(headers.get("PAYMENT-SIGNATURE"), "retry must include PAYMENT-SIGNATURE");
  return new Response('{"ok":true}', { status: 200 });
};

const paidFetch = wrapFetchWithPayment(mockFetch, client);
const response = await paidFetch("https://api.tradingzones.app/v1/signals/BTC/4h");
assert.equal(response.status, 200);
assert.equal(calls, 2);
assert.equal(signed, true);
console.log("x402 browser client smoke test: OK");
