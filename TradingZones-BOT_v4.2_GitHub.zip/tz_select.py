from __future__ import annotations

import json
import math
import ssl
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request

from secure_http import safe_urlopen as urlopen

try:
    import truststore
except ImportError:  # Testy i środowiska bez opcjonalnej integracji Windows TLS.
    truststore = None


PROMO_URL = "https://api.tradingzones.app/v1/promo/TZ-SELECT/4h"
ALLOWED_SYMBOLS = {"BTC", "ETH", "XRP", "ONDO"}


class TzSelectError(RuntimeError):
    pass


class TzSelectRefreshing(TzSelectError):
    def __init__(self, message: str, retry_after: int = 0):
        super().__init__(message)
        self.retry_after = max(0, int(retry_after or 0))


def tls_context():
    """Windows certificate store when available, safe system TLS otherwise."""
    return (
        truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        if truststore is not None
        else ssl.create_default_context()
    )


def _iso(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        parsed = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return parsed if math.isfinite(parsed) else None


def validate_package(
    payload: Any,
    now: datetime | None = None,
    expected_product: str | None = None,
) -> dict[str, Any]:
    """Fail-closed validation for a free TZ SELECT package."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    if not isinstance(payload, dict):
        raise TzSelectError("API nie zwróciło obiektu JSON.")

    schema = str(payload.get("schema_version") or "")
    if schema != "1.4":
        raise TzSelectError(f"Nieobsługiwana wersja schematu: {schema or 'brak'}.")

    symbol = str(payload.get("symbol") or "").upper()
    interval = str(payload.get("interval") or "").lower()
    action = str(payload.get("action") or "").upper()
    decision = str(payload.get("decision") or "").upper()
    direction = str(payload.get("direction") or "").upper()
    if symbol not in ALLOWED_SYMBOLS:
        raise TzSelectError("TZ SELECT zwrócił nieobsługiwany symbol.")
    expected_product = str(expected_product or "").upper()
    if expected_product and expected_product != "TZ-SELECT" and symbol != expected_product:
        raise TzSelectError("Symbol pakietu nie zgadza się z wybranym produktem.")
    if interval != "4h":
        raise TzSelectError("Pakiet nie dotyczy interwału 4H.")
    if action not in {"TRADE", "NO_TRADE"}:
        raise TzSelectError("Nieznana akcja w pakiecie.")

    valid_until = _iso(payload.get("valid_until"))
    if valid_until is None:
        raise TzSelectError("Brak poprawnego valid_until.")
    if now >= valid_until:
        raise TzSelectError("Analiza wygasła. Pobierz nowy cykl TZ SELECT.")

    selector = payload.get("tz_select")
    is_selector_product = expected_product == "TZ-SELECT" or isinstance(selector, dict)
    selector_until = None
    if is_selector_product:
        if not isinstance(selector, dict):
            raise TzSelectError("Brak potwierdzenia wyboru TZ SELECT.")
        if str(selector.get("selected_symbol") or "").upper() != symbol:
            raise TzSelectError("Symbol pakietu nie zgadza się z wyborem TZ SELECT.")
        selector_until = _iso(selector.get("selection_valid_until"))
        if selector_until is None or now >= selector_until:
            raise TzSelectError("Wybór TZ SELECT wygasł.")

    entry_data = payload.get("entry") or {}
    levels = payload.get("levels") or {}
    entry = _number(entry_data.get("b2b_reference_price"))
    if entry is None:
        entry = _number(levels.get("entry_reference"))
    sl_lq = _number(levels.get("stop_loss_liquidity_guard"))
    tp_lq = _number(levels.get("take_profit_liquidity_guard"))
    setup_strength = _number(payload.get("setup_strength_score"))

    tradable = payload.get("tradable") is True
    if action == "TRADE":
        if not tradable or decision not in {"LONG", "SHORT"}:
            raise TzSelectError("Pakiet TRADE ma niespójną decyzję.")
        if direction != decision:
            raise TzSelectError("Kierunek nie zgadza się z decyzją.")
        if entry is None or sl_lq is None or tp_lq is None:
            raise TzSelectError("Brakuje Entry, SL LQ lub TP LQ — zlecenie zablokowane.")
        if entry <= 0 or sl_lq <= 0 or tp_lq <= 0:
            raise TzSelectError("Pakiet zawiera niepoprawny poziom ceny.")
        geometry_ok = (
            direction == "LONG" and sl_lq < entry < tp_lq
        ) or (
            direction == "SHORT" and tp_lq < entry < sl_lq
        )
        if not geometry_ok:
            raise TzSelectError("Geometria Entry / SL LQ / TP LQ jest niepoprawna.")
    else:
        if tradable:
            raise TzSelectError("Pakiet NO_TRADE nie może być oznaczony jako tradable.")

    effective_until = min(valid_until, selector_until) if selector_until else valid_until
    return {
        "schema_version": schema,
        "package_id": str(payload.get("package_id") or ""),
        "delivery_id": str(payload.get("delivery_id") or ""),
        "symbol": symbol,
        "interval": interval,
        "action": action,
        "tradable": tradable,
        "decision": decision,
        "direction": direction,
        "reason_code": str(payload.get("reason_code") or ""),
        "reason": str(payload.get("reason") or ""),
        "setup_strength_score": setup_strength,
        "confidence_band": str(payload.get("confidence_band") or ""),
        "entry_reference": entry,
        "sl_lq": sl_lq,
        "tp_lq": tp_lq,
        "generated_at": payload.get("generated_at"),
        "valid_until": effective_until.isoformat().replace("+00:00", "Z"),
        "seconds_remaining": max(0, int((effective_until - now).total_seconds())),
        "selection_id": str((selector or {}).get("selection_id") or ""),
        "context": payload.get("context") or {},
        "indicators": payload.get("indicators") or {},
        "risk_reward_status": str(payload.get("risk_reward_status") or ""),
        "selection_context": str(payload.get("selection_context") or ""),
        "attribution": str(payload.get("attribution") or ""),
        "candle_closed_at": payload.get("candle_closed_at"),
        "source_analysis_candle_time": payload.get("source_analysis_candle_time"),
        "signal_id": str(payload.get("signal_id") or ""),
        "revision": payload.get("revision"),
        "product": expected_product or ("TZ-SELECT" if is_selector_product else symbol),
        "tz_select": selector or {},
        "performance_evidence": payload.get("performance_evidence") or {},
        "live_execution_evidence": payload.get("live_execution_evidence") or {},
        "usage_license": payload.get("usage_license") or {},
    }


def fetch_free_package(timeout: int = 15) -> dict[str, Any]:
    request = Request(
        PROMO_URL,
        headers={
            "Accept": "application/json",
            "User-Agent": "TradingZones-BOT/1.0",
        },
    )
    context = tls_context()
    try:
        with urlopen(request, timeout=timeout, context=context) as response:
            raw = response.read()
    except HTTPError as exc:
        body = exc.read()
        if exc.code == 503:
            try:
                data = json.loads(body.decode("utf-8"))
            except Exception:
                data = {}
            raise TzSelectRefreshing(
                str(data.get("detail") or data.get("reason") or "Dane są odświeżane."),
                int(data.get("retry_after") or data.get("retryAfterSeconds") or 0),
            ) from exc
        raise TzSelectError(f"API zwróciło HTTP {exc.code}.") from exc
    except (URLError, TimeoutError, OSError) as exc:
        raise TzSelectError(f"Nie udało się połączyć z Trading Zones: {exc}") from exc

    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise TzSelectError("API zwróciło niepoprawny JSON.") from exc
    return validate_package(payload, expected_product="TZ-SELECT")
